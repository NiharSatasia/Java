package prj0;

import java.util.*;

/**
 * 
 * @author Nihar Satasia
 */

 
public class Project0 {
    
    ArrayList<LinkedList<Integer>> adj;
    private static Scanner sc;
    
	public static void main(String[] args) {
	    
		sc = new Scanner(System.in);
		
		StringBuilder output = new StringBuilder();
		output.append("");
		
		int N = sc.nextInt();
	    int M = sc.nextInt();
	    int Q = sc.nextInt();
	    int track;
	    
	    ArrayList<LinkedList<Integer>> adj = new ArrayList<LinkedList<Integer>>();
	    
	    if(N < 1 || N > 100000|| M < 0 || M > 500000 || Q < 1 || Q > N)
	    {
	        output.append("-1");	        
	    }
	    else
	    {
	        for(int i = 0; i < N+1; i++)
	        {
	            adj.add(new LinkedList<Integer>());
	        }
	        for(int i = 1; i < M+1; i++)
	        {
	            addEdge(adj, sc.nextInt(), sc.nextInt());
	        }

	        for(int i = 0; i < Q; i++)
	        {
	            track = sc.nextInt();
	            if(adj.get(track).isEmpty())
	            {
	               
	                output.append("-1" + " " + "\n");
	            }
	            else
	            {
	            output.append(adj.get(track) + " " + "\n");
	            }
	        }
	    }
	    
	    System.out.println(output.toString().replace(",", "").replace("[", "").replace("]", ""));
	}

	public static void addEdge(ArrayList<LinkedList<Integer>> adj, int u, int v)
	{
	    adj.get(u).add(v);
	    adj.get(v).add(u);
	}
	



}

