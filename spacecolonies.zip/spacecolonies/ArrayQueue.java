// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package spacecolonies;

import queue.EmptyQueueException;
import queue.QueueInterface;

/**
 * This class is to implement
 * ArrayQueue functionalities.
 * 
 * @param <T>
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class ArrayQueue<T> implements QueueInterface<T> {
    // ~ Fields ................................................................
    private T[] queue;
    /**
     * Default capacity
     */
    public static final int DEFAULT_CAPACITY = 20;
    private int enqueueIndex;
    private int dequeueIndex;
    private int size;

    /**
     * Default constructor calling clear
     * (clear resets the constructors variables
     * so it is a way to recall the constructor).
     */
    public ArrayQueue() {
        clear();
    }


    /**
     * Default constructor
     * 
     * @param initialCapacity
     *            - capacity of queue
     */
    public ArrayQueue(int initialCapacity) {
        size = 0;
        dequeueIndex = 0;
        enqueueIndex = DEFAULT_CAPACITY;
        @SuppressWarnings("unchecked")
        T[] ts = (T[])new Object[DEFAULT_CAPACITY + 1];
        queue = ts;
    }


    /**
     * Gets the length of the ArrayQueue
     * 
     * @return length of ArrayQueue
     */
    public int getLengthOfUnderlyingArray() {
        return queue.length;
    }


    /**
     * Gets the size of the ArrayQueue
     * 
     * @return size of queue
     */
    public int getSize() {
        return size;
    }


    /**
     * Determines if the ArrayQueue is empty
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }


    /**
     * Determines if the ArrayQueue is full
     * 
     * @return true if it is
     */
    private boolean isFull() {
        return dequeueIndex == (enqueueIndex + 2) % queue.length;
    }


    /**
     * Adds item to end of queue
     * 
     * @param newEntry
     *            - entry being added
     */
    @Override
    public void enqueue(T newEntry) {

        ensureCapacity();
        enqueueIndex = incrementIndex(enqueueIndex);
        queue[enqueueIndex] = newEntry;
        size++;
    }


    /**
     * Helper method to upgrade length of underlying array
     * when ArrayQueue is full.
     */
    @SuppressWarnings("unchecked")
    private void ensureCapacity() {
        if (isFull()) {
            T[] oldQueue = queue;
            int oldSize = oldQueue.length;
            // 21 * 2 - 1 = 41
            int newSize = 2 * oldSize - 1;
            queue = (T[])new Object[newSize];
            int j = dequeueIndex;
            for (int i = 0; i < oldSize - 1; i++) {
                queue[i] = oldQueue[j];
                j = (j + 1) % oldSize;
            }
            dequeueIndex = 0;
            enqueueIndex = oldSize - 2;
        }
    }


    /**
     * Removes from front of ArrayQueue
     * 
     * @return dequeue object removed
     */
    @Override
    public T dequeue() {
        T front = getFront();
        queue[dequeueIndex] = null;
        dequeueIndex = incrementIndex(dequeueIndex);
        size--;
        return front;
    }


    /**
     * Gets the object in front of ArrayQueue
     * 
     * @return front object
     */
    @Override
    public T getFront() {
        if (isEmpty()) {
            throw new EmptyQueueException();
        }
        else {
            return queue[dequeueIndex];
        }
    }


    /**
     * Empties the queue.
     */
    @SuppressWarnings("unchecked")
    @Override
    public void clear() {
        enqueueIndex = DEFAULT_CAPACITY;
        dequeueIndex = 0;
        size = 0;
        T[] ts = (T[])new Object[DEFAULT_CAPACITY + 1];
        queue = ts;
    }


    /**
     * Helper method for circular queue wrapping.
     * 
     * @param index
     * @return updated index.
     */
    private int incrementIndex(int index) {
        return ((index + 1) % queue.length);
    }


    /**
     * Converts the ArrayQueue into an array
     * 
     * @return the new array
     */
    public Object[] toArray() {
        if (isEmpty()) {
            throw new EmptyQueueException();
        }
        Object[] array = new Object[size];
        int j = dequeueIndex;
        for (int i = 0; i < size; i++) {
            array[i] = queue[j];
            j = (j + 1) % queue.length;
        }
        return array;
    }


    /**
     * Converts the ArrayQueue into a string
     * 
     * @return array in string form
     */
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }
        StringBuilder s = new StringBuilder();
        // beginning bracket
        s.append("[");
        for (int i = 0; i < size; i++) {
            if (i == 0) {
                s.append(queue[dequeueIndex]);
            }
            else {
                s.append(queue[incrementIndex(dequeueIndex + (i - 1))]);
            }
            // accounts for the commas
            if (i != size - 1) {
                s.append(", ");
            }
        }
        // end bracket
        s.append("]");
        return s.toString();
    }


    /**
     * Determines if two ArrayQueues are equal
     * 
     * @param obj
     *            - other object for comparison
     * @return true if they are equal
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass().equals(obj.getClass())) {
            @SuppressWarnings("unchecked")
            ArrayQueue<T> aqObj = (ArrayQueue<T>)obj;
            if (this.getSize() == aqObj.getSize()) {
                for (int i = 0; i < size; i++) {
                    T myElement = queue[(dequeueIndex + i) % queue.length];
                    T otherElement = aqObj.queue[(aqObj.dequeueIndex + i)
                        % aqObj.queue.length];
                    if (!myElement.equals(otherElement)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

}
