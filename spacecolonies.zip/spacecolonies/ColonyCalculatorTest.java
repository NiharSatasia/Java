// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import student.TestCase;

/**
 * Test class for colony calculator
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class ColonyCalculatorTest extends TestCase {
    // ~ Fields ................................................................
    // private ColonyCalculator cc1;
    // private ArrayQueue<Person> aq;
    // private Planet p11;
    // private Planet p22;
    // private Planet p33;
    // private Person pe1;
    // private Person pe2;
    // private Person pe3;
    // @SuppressWarnings("unused")
    // private Planet[] array;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        // aq = new ArrayQueue<Person>();
        // p11 = new Planet("a", 1, 2, 3, 4);
        // p22 = new Planet("b", 2, 3, 4, 5);
        // p33 = new Planet("c", 3, 4, 5, 6);
        // Planet[] array = {null, p11, p22, p33};
        // pe1 = new Person("b", 6, 7, 8, "Venus");
        // pe2 = new Person("e", 1, 1, 1, "Earth");
        // cc1 = new ColonyCalculator(aq, array);
    }


    /**
     * Tests to see if getQueue works as intended.
     */
    public void testGetQueue() {
        ArrayQueue<Person> aq = new ArrayQueue<Person>();
        Planet p11 = new Planet("a", 1, 2, 3, 4);
        Planet p22 = new Planet("b", 2, 3, 4, 5);
        Planet p33 = new Planet("c", 3, 4, 5, 6);
        Person pe1 = new Person("b", 6, 7, 8, "Venus");
        Planet[] array = { null, p11, p22, p33 };
        ColonyCalculator cc1 = new ColonyCalculator(aq, array);
        
        
        cc1.getQueue().enqueue(pe1);
        assertEquals(1, cc1.getQueue().getSize());
    }

    /**
     * Tests to see if getPlanets works as intended.
     */
    // public void testGetPlanets() {
    // array = cc1.getPlanets();
    // assertEquals(p11, cc1.getPlanets());
    // }

}
