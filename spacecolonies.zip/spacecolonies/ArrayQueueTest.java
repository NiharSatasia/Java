// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import queue.EmptyQueueException;
import student.TestCase;

/**
 * Test class for ArrayQueue.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

public class ArrayQueueTest extends TestCase {

    // ~ Fields ................................................................
    private ArrayQueue<Person> aq1;
    private ArrayQueue<Person> aq2;
    private Person p1;
    private Person p2;
    private Person p3;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        aq1 = new ArrayQueue<Person>();
        aq2 = new ArrayQueue<Person>();
        p1 = new Person("a", 1, 2, 3, "Earth");
        p2 = new Person("b", 2, 3, 4, "Mars");
        p3 = new Person("a", 1, 2, 3, "Earth");
    }


    /**
     * Tests to see if getLengthOfUnderlyingArray
     * works as intended.
     */
    public void testGetLengthOfUnderlyingArray() {
        assertEquals(21, aq1.getLengthOfUnderlyingArray());
    }


    /**
     * Tests to see if getSize works as intended.
     */
    public void testGetSize() {
        assertEquals(0, aq1.getSize());
        aq1.enqueue(p1);
        assertEquals(1, aq1.getSize());
    }


    /**
     * Tests to see if isEmpty works as intended.
     */
    public void testIsEmpty() {
        assertTrue(aq1.isEmpty());
        aq1.enqueue(p1);
        assertFalse(aq1.isEmpty());
    }


    /**
     * Tests to see if enqueue works as intended.
     */
    public void testEnqueue() {
        assertTrue(aq1.isEmpty());
        aq1.enqueue(p1);
        assertFalse(aq1.isEmpty());
        assertEquals(1, aq1.getSize());
    }


    /**
     * Tests to see if dequeue works as intended.
     */
    public void testDequeue() {
        Exception thrown = null;
        try {
            aq1.dequeue();
        }
        catch (Exception exception) {
            thrown = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown instanceof EmptyQueueException);

        aq1.enqueue(p1);
        aq1.enqueue(p2);
        aq1.enqueue(p3);
        assertEquals(p1, aq1.dequeue());
        assertEquals(2, aq1.getSize());
    }


    /**
     * Tests to see if getFront works as intended.
     */
    public void testGetFront() {
        aq1.enqueue(p1);
        aq1.enqueue(p2);
        aq1.enqueue(p3);
        aq2.enqueue(p1);
        assertEquals(p1, aq2.getFront());
    }


    /**
     * Tests to see if clear works as intended.
     */
    public void testClear() {
        aq1.enqueue(p1);
        aq1.enqueue(p2);
        aq1.enqueue(p3);
        aq1.clear();
        assertTrue(aq1.isEmpty());
    }


    /**
     * Tests to see if toArray works as intended.
     */
    public void testToArray() {
        aq1.enqueue(p1);
        aq1.enqueue(p2);
        Person[] testArray = new Person[3];
        testArray[0] = p1;
        testArray[1] = p2;

        assertEquals(testArray[0], aq1.toArray()[0]);

    }


    /**
     * Tests to see if toString works as intended.
     */
    public void testToString() {
        aq1.enqueue(p1);
        aq1.enqueue(p2);
        aq1.enqueue(p3);

        assertEquals("[a A:1 M:2 T:3 Wants: Earth, b A:2 "
            + "M:3 T:4 Wants: Mars, a A:1 M:2 T:3 Wants: " + "Earth]", aq1
                .toString());
    }


    /**
     * Tests to see if equals works as intended.
     */
    public void testEquals() {
        assertTrue(aq1.equals(aq1));
        assertFalse(aq1.equals(null));
        aq1.enqueue(p1);
        aq1.enqueue(p2);
        aq1.enqueue(p3);
        aq2.enqueue(p1);
        aq2.enqueue(p2);
        assertFalse(aq1.equals(aq2));
        aq2.enqueue(p3);
        assertTrue(aq1.equals(aq2));

    }
}
