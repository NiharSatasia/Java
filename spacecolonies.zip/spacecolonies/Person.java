// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

/**
 * This class is used
 * to create various person objects.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class Person {
    // ~ Fields ................................................................
    private String name;
    private Skillset skills;
    private String planetPreference;

    /**
     * Default person constructor
     * 
     * @param name
     *            of person
     * @param agri
     *            skillset
     * @param medi
     *            skillset
     * @param tech
     *            skillset
     * @param planet
     *            of person
     */
    public Person(String name, int agri, int medi, int tech, String planet) {
        this.name = name;
        this.skills = new Skillset(agri, medi, tech);
        this.planetPreference = planet;
    }


    /**
     * Getter method for name
     * 
     * @return name of person
     */
    public String getName() {
        return name;
    }


    /**
     * Getter method for skills
     * 
     * @return skills - the skillset
     */
    public Skillset getSkills() {
        return skills;
    }


    /**
     * Getter method for planet
     * 
     * @return planet of person
     */
    public String getPlanetPreference() {
        return planetPreference;
    }


    /**
     * Method that returns the person object as a string
     * 
     * @return string of person
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        if (planetPreference.length() == 0) {
            s.append("No-Planet " + name + " " + skills.toString());
        }
        if (planetPreference.length() > 0) {
            s.append(name + " " + skills.toString() + " Wants: "
                + planetPreference);
        }
        return s.toString();
    }


    /**
     * Method that determines if two person objects are equal.
     * 
     * @param obj
     *            - the object to compare to
     * @return true if the two objects have the same name,
     *         skillset, and planet preference, false otherwise
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass().equals(obj.getClass())) {
            // Accounts for if the classes are same but the qualities are not.
            Person objPerson = (Person)obj;
            return (this.getName().equals(objPerson.getName()) && this.skills
                .equals(objPerson.skills) && this.getPlanetPreference().equals(
                    objPerson.getPlanetPreference()));
        }

        return false;
    }
}
