// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import student.TestCase;

/**
 * Test class for Skillset.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

public class SkillsetTest extends TestCase {
    // ~ Fields ................................................................
    private Skillset skill1;
    private Skillset skill2;
    private Skillset skill3;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        skill1 = new Skillset(5, 3, 1);
        skill2 = new Skillset(6, 7, 2);
        skill3 = new Skillset(5, 3, 1);
    }


    /**
     * Tests to see if getAgriculture works as intended.
     */
    public void testGetAgriculture() {
        assertEquals(5, skill1.getAgriculture());
    }


    /**
     * Tests to see getMedicine works as intended.
     */
    public void testGetMedicine() {
        assertEquals(3, skill1.getMedicine());
    }


    /**
     * Tests to see getTechnology works as intended.
     */
    public void testGetTechnology() {
        assertEquals(1, skill1.getTechnology());
    }


    /**
     * Tests to see if isLessThanOrEqualsTo works as intended.
     */
    public void testIsLessThanOrEqualsTo() {
        assertTrue(skill1.isLessThanOrEqualTo(skill2));
        assertTrue(skill1.isLessThanOrEqualTo(skill3));
        assertFalse(skill2.isLessThanOrEqualTo(skill3));
    }


    /**
     * Tests to see if toString works as intended.
     */
    public void testToString() {
        assertEquals("A:5 M:3 T:1", skill1.toString());
    }


    /**
     * Tests to see if equals works as intended
     */
    public void testEquals() {
        assertTrue(skill1.equals(skill1));
        assertFalse(skill1.equals(skill2));
        assertFalse(skill2.equals(skill3));
        assertTrue(skill1.equals(skill3));
        assertFalse(skill1.equals(new Object()));
        assertFalse(skill1.equals(null));
    }


    /**
     * Tests to see if compareTo works as intended
     */
    public void testCompareTo() {
        assertEquals(0, skill1.compareTo(skill3));
        assertEquals(-1, skill1.compareTo(skill2));
        assertEquals(1, skill2.compareTo(skill1));
    }

}
