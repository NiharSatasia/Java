// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import student.TestCase;

/**
 * Test class for Planet.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

public class PlanetTest extends TestCase {

    // ~ Fields ................................................................
    private Planet planet1;
    private Planet planet3;
    private Planet planet4;
    private Planet planet5;
    private Planet planet6;
    private Planet planet7;
    private Person person1;
    private Person person2;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        planet1 = new Planet("a", 2, 3, 4, 5);
        planet3 = new Planet("f", 3, 4, 5, 6);
        planet4 = new Planet("g", 4, 5, 6, 6);
        planet5 = new Planet("g", 4, 5, 6, 6);
        planet6 = new Planet("z", 4, 5, 6, 6);
        planet7 = new Planet("za", 4, 5, 6, 6);
        person1 = new Person("b", 6, 7, 8, "Venus");
        person2 = new Person("e", 1, 1, 1, "Earth");
    }


    /**
     * Tests to see if the setName method works as intended.
     */
    public void testSetName() {
        planet1.setName("d");
        assertEquals("d", planet1.getName());
    }


    /**
     * Tests to see if the getName method works as intended.
     */
    public void testGetName() {
        assertEquals("a", planet1.getName());
    }


    /**
     * Tests to see if the getSkills method works as intended.
     */
    public void testGetSkills() {
        assertEquals("A:2 M:3 T:4", planet1.getSkills().toString());
    }


    /**
     * Tests to see if the getPopulation method works as intended.
     */
    public void testGetPopulation() {
        planet1.addPerson(person1);
        assertEquals(1, planet1.getPopulationSize());
        assertEquals(person1, planet1.getPopulation()[0]);
        planet1.addPerson(person2);
        assertEquals(1, planet1.getPopulationSize());
    }


    /**
     * Tests to see if getPopilationSize works as intended.
     */
    public void testGetPopulationSize() {
        assertEquals(0, planet1.getPopulationSize());
        planet1.addPerson(person1);
        assertEquals(1, planet1.getPopulationSize());
    }


    /**
     * Tests to see if getCapacity works as intended.
     */
    public void testGetcapacity() {
        assertEquals(5, planet1.getCapacity());
    }


    /**
     * Tests to see if getAvailability works as intended.
     */
    public void testGetAvailability() {
        planet1.addPerson(person1);
        assertEquals(4, planet1.getAvailability());
    }


    /**
     * Tests to see if isFull works as intended.
     */
    public void testIsFull() {
        planet1.addPerson(person1);
        planet1.addPerson(person1);
        planet1.addPerson(person1);
        planet1.addPerson(person1);
        assertFalse(planet1.isFull());
        planet1.addPerson(person1);
        assertTrue(planet1.isFull());
        assertFalse(planet1.addPerson(person1));
    }


    /**
     * Tests to see if addPerson works as intended.
     */
    public void testAddPerson() {
        assertEquals(0, planet1.getPopulationSize());
        planet1.addPerson(person1);
        assertEquals(person1, planet1.getPopulation()[0]);

    }


    /**
     * Tests to see if isQualified works as intended.
     */
    public void testIsQualified() {
        assertTrue(planet1.isQualified(person1));
        assertFalse(planet1.isQualified(person2));
    }


    /**
     * Tests to see if toString works as intended.
     */
    public void testToString() {
        assertEquals("a, population 0 (cap: 5), Requires: A >= 2, "
            + "M >= 3, T >= 4", planet1.toString());
    }


    /**
     * Tests to see if compareTo works as intended.
     */
    public void testCompareTo() {
        assertEquals(-1, planet1.compareTo(planet3));
        assertEquals(1, planet4.compareTo(planet3));

        planet3.addPerson(person1);
        assertEquals(-1, planet3.compareTo(planet4));
        assertEquals(1, planet4.compareTo(planet3));

        planet4.addPerson(person1);
        assertEquals(-1, planet3.compareTo(planet4));
        assertEquals(1, planet4.compareTo(planet3));

        assertEquals(-1, planet6.compareTo(planet7));
        assertEquals(1, planet7.compareTo(planet6));

        planet5.addPerson(person1);
        assertEquals(0, planet4.compareTo(planet5));

        // assertEquals(1, planet6.compareTo(planet7));
    }


    /**
     * Tests to see if equals works as intended.
     */
    public void testEquals() {
        assertTrue(planet1.equals(planet1));
        assertFalse(planet1.equals(null));
        assertFalse(planet1.equals(new Object()));
        assertFalse(planet1.equals(planet4));
        assertTrue(planet4.equals(planet5));
        planet4.addPerson(person1);
        assertFalse(planet4.equals(planet5));
        planet5.addPerson(person1);
        assertTrue(planet4.equals(planet5));
    }

}
