// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

/**
 * This class is meant to create
 * planet objects by implementing Comparable<Planet>
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

public class Planet implements Comparable<Planet> {
    // ~ Fields ................................................................
    private String name;
    private Skillset minSkills;
    private Person[] population;
    private int populationSize;
    private int capacity;

    /**
     * Planet Constructor
     * 
     * @param planetName
     *            - string name
     * @param planetAgri
     *            - int agriculture score
     * @param planetMedi
     *            - int medical score
     * @param planetTech
     *            - int tech score
     * @param planetCap
     *            - int capacity
     */
    public Planet(
        String planetName,
        int planetAgri,
        int planetMedi,
        int planetTech,
        int planetCap) {
        this.name = planetName;
        this.minSkills = new Skillset(planetAgri, planetMedi, planetTech);
        this.capacity = planetCap;
        this.population = new Person[capacity];
        this.populationSize = 0;
    }


    /**
     * Sets the name of the planet.
     * 
     * @param name1
     *            - name of planet
     */
    public void setName(String name1) {
        name = name1;
    }


    /**
     * Gets the name of the planet.
     * 
     * @return name - name of planet as a string
     */
    public String getName() {
        return name;
    }


    /**
     * Gets the skills needed.
     * 
     * @return minSkills - skills needed.
     */
    public Skillset getSkills() {
        return minSkills;
    }


    /**
     * Gets the population of planet.
     * 
     * @return population - as an array.
     */
    public Person[] getPopulation() {
        return population;
    }


    /**
     * Gets the size of population.
     * 
     * @return populationSize - as an integer.
     */
    public int getPopulationSize() {
        return populationSize;
    }


    /**
     * Gets the capacity of the planet.
     * 
     * @return capacity - max number of people.
     */
    public int getCapacity() {
        return capacity;
    }


    /**
     * Gets the available room on the planet.
     * 
     * @return integer of space left.
     */
    public int getAvailability() {
        return capacity - populationSize;
    }


    /**
     * Determines if the planet is full.
     * 
     * @return T or F depending on if the planet is full.
     */
    public boolean isFull() {
        return capacity == populationSize;
    }


    /**
     * Determines of the person can be added.
     * 
     * @param newbie
     *            - person trying to be added.
     * @return - true or false depending on if the add
     *         is successful
     */
    public boolean addPerson(Person newbie) {
        if (capacity != populationSize && isQualified(newbie)) {
            population[populationSize] = newbie;
            populationSize++;
            return true;
        }
        else {
            return false;
        }
    }


    /**
     * Helper method for addPerson.
     * Determines if a person meets the qualifications for the planet.
     * 
     * @param qual
     *            - person being added
     * @return T or F depending on skillset
     */
    public boolean isQualified(Person qual) {
        return !qual.getSkills().isLessThanOrEqualTo(minSkills);
    }


    /**
     * Converts the planet to a string.
     * 
     * @return the planet in string form.
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(name);
        s.append(", population " + populationSize);
        s.append(" (cap: " + capacity + "), ");
        s.append("Requires: A >= " + minSkills.getAgriculture() + ", M >= "
            + minSkills.getMedicine() + ", T >= " + minSkills.getTechnology());
        return s.toString();

    }


    /**
     * Compares two planets based on their capacities.
     * 
     * @param other
     *            - other object being compared to
     * @return 0, 1, -1 depending on the comparisons
     */
    @Override
    public int compareTo(Planet other) {
        // comparison hierarchy: capacity, availability, skillset, name
        if (this.getCapacity() > other.getCapacity()) {
            return 1;
        }
        else if (this.getCapacity() < other.getCapacity()) {
            return -1;
        }
        else if (this.getAvailability() > other.getAvailability()) {
            return 1;
        }
        else if (this.getAvailability() < other.getAvailability()) {
            return -1;
        }
        else if (this.getSkills().compareTo(other.getSkills()) == 0) {
            return this.getName().compareTo(other.getName());
        }
        else {
            return this.getSkills().compareTo(other.getSkills());
        }
    }


    /**
     * Determines if two planet objects are equal.
     * 
     * @param obj
     *            to be compared to
     * @return true if the two objects are equal.
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass().equals(obj.getClass())) {
            // Accounts for if the classes are same but the qualities are not.
            Planet objPlanet = (Planet)obj;
            return (this.getName().equals(objPlanet.getName()) && this.minSkills
                .equals(objPlanet.minSkills) && this.getCapacity() == objPlanet
                    .getCapacity()) && this.getPopulationSize() == objPlanet
                        .getPopulationSize();
        }

        return false;
    }
}
