// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import java.io.FileNotFoundException;
import java.text.ParseException;

/**
 * Used to demonstrate the functionality of SpaceColonies.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class ProjectRunner {
    /**
     * Main method that runs through configuarations
     * 
     * @param args
     * @throws FileNotFoundException
     * @throws ParseException
     * @throws SpaceColonyDataExceptiom
     */
    public static void main(String[] args)
        throws FileNotFoundException,
        ParseException,
        SpaceColonyDataException {
        if (args.length == 2) {
            new ColonyReader(args[0], args[1]);
        }
        else {
            new ColonyReader("input.txt", "planets.txt");
        }
    }

}
