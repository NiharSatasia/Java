// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

/**
 * This class extends implements Comparable<Skillset>
 * to create various skill objects.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class Skillset implements Comparable<Skillset> {
    // ~ Fields ................................................................
    private int agriculture;
    private int medicine;
    private int technology;

    /**
     * Default constructor that assigns values to the fields.
     * 
     * @param ag
     *            - agriculture
     * @param med
     *            - medicine
     * @param tech
     *            - technology
     */
    public Skillset(int ag, int med, int tech) {
        this.agriculture = ag;
        this.medicine = med;
        this.technology = tech;
    }


    /**
     * Getter method for agriculture.
     * 
     * @return integer agriculture
     */
    public int getAgriculture() {
        return agriculture;
    }


    /**
     * Getter method for medicine.
     * 
     * @return integer medicine
     */
    public int getMedicine() {
        return medicine;
    }


    /**
     * Getter method for technology.
     * 
     * @return integer technology
     */
    public int getTechnology() {
        return technology;
    }


    /**
     * Compares a skillset object to another
     * 
     * @param other
     *            - other skillset object for comparison.
     * @return true if "this" is <= to "other"
     */
    public boolean isLessThanOrEqualTo(Skillset other) {
        return (this.agriculture <= other.agriculture
            && this.medicine <= other.medicine
            && this.technology <= other.technology);
    }


    /**
     * Converts the skills into strings.
     * 
     * @return the skills as strings
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("A:" + getAgriculture());
        s.append(" M:" + getMedicine());
        s.append(" T:" + getTechnology());
        return s.toString();
    }


    /**
     * Determines if two skillset objects are equal
     * 
     * @param obj
     *            to be compared to
     * @return true if the two objects are equal
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass().equals(obj.getClass())) {
            // Accounts for if the classes are same but the skillsets are not.
            Skillset objSkillset = (Skillset)obj;
            return (this.getAgriculture() == objSkillset.getAgriculture()
                && this.getMedicine() == objSkillset.getMedicine() && this
                    .getTechnology() == objSkillset.getTechnology());
        }

        return false;
    }


    /**
     * Compares two skillset objects
     * 
     * @param skills
     *            - skillset object to be compared to
     * @return 0 if they are equal, -1 if "this" is less
     *         than "skills", and 1 if "this" is more than "skills"
     */
    @Override
    public int compareTo(Skillset skills) {
        int sum1 = this.getAgriculture() + this.getMedicine() + this
            .getTechnology();

        int sum2 = skills.getAgriculture() + skills.getMedicine() + skills
            .getTechnology();

        if (sum1 == sum2) {
            return 0;
        }
        else if (sum1 < sum2) {
            return -1;
        }
        else {
            return 1;
        }

    }

}
