// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import java.io.FileNotFoundException;
import java.text.ParseException;
import student.TestCase;

/**
 * Test class for SpaceColonyDataException
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 * 
 */
public class SpaceColonyDataExceptionTest extends TestCase {
    // ~ Fields ................................................................
    private Object exc;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        exc = new SpaceColonyDataException("exception");
    }


    /**
     * Tests to see if exception is thrown
     * 
     * @throws SpaceColonyDataException
     * @throws ParseException
     * @throws FileNotFoundException
     */
    public void testException()
        throws FileNotFoundException,
        ParseException,
        SpaceColonyDataException {
        new ColonyReader("input.txt", "planets.txt");
        assertNotNull(exc);
    }
}
