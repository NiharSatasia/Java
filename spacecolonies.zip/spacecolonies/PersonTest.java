// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import student.TestCase;

/**
 * Test class for Planet.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

public class PersonTest extends TestCase {

    // ~ Fields ................................................................
    private Person person1;
    private Person person2;
    private Person person3;
    private Person person4;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        person1 = new Person("Nihar", 2, 3, 4, "Mars");
        person2 = new Person("Satasia", 3, 4, 5, "Venus");
        person3 = new Person("NS", 2, 3, 4, "");
        person4 = new Person("NS", 2, 3, 4, "");

    }


    /**
     * Tests to see if getName works as intended.
     */
    public void testGetName() {
        assertEquals("Nihar", person1.getName());
    }


    /**
     * Tests to see if getSkills works as intended.
     */
    public void testGetSkills() {
        assertEquals("A:2 M:3 T:4", person1.getSkills().toString());
    }


    /**
     * Tests to see if getPlanetPreference works as intended.
     */
    public void testGetPlanetPreference() {
        assertEquals("Mars", person1.getPlanetPreference());
    }


    /**
     * Tests to see if toString works as intended.
     */
    public void testToString() {
        assertEquals("Nihar A:2 M:3 T:4 Wants: Mars", person1.toString());
        assertEquals("No-Planet NS A:2 M:3 T:4", person3.toString());
    }


    /**
     * Tests to see if equals works as intended.
     */
    public void testEquals() {
        assertTrue(person1.equals(person1));
        assertFalse(person1.equals(person2));
        assertFalse(person1.equals(new Object()));
        assertFalse(person1.equals(null));
        assertTrue(person3.equals(person4));
    }

}
