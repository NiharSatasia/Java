// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Scanner;

/**
 * This class parses input data from two text files
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class ColonyReader {
    // ~ Fields ................................................................
    private Planet[] planets;
    private ArrayQueue<Person> queue;

    /**
     * helper method that determines if the integers
     * that are passed are between the min and max possible
     * values for a skill
     * 
     * @param num1
     * @param num2
     * @param num3
     * @return
     */
    private boolean isInSkillRange(int num1, int num2, int num3) {
        return (num1 <= ColonyCalculator.MAX_SKILL_LEVEL
            && num1 >= ColonyCalculator.MIN_SKILL_LEVEL
            && num2 <= ColonyCalculator.MAX_SKILL_LEVEL
            && num2 >= ColonyCalculator.MIN_SKILL_LEVEL
            && num3 <= ColonyCalculator.MAX_SKILL_LEVEL
            && num3 >= ColonyCalculator.MIN_SKILL_LEVEL);
    }


    public ColonyReader(String applicantFileName, String planetFileName)
        throws FileNotFoundException,
        ParseException,
        SpaceColonyDataException {
        queue = readQueueFile(applicantFileName);
        planets = readPlanetFile(planetFileName);

        new SpaceWindow(new ColonyCalculator(queue, planets));
    }


    /**
     * Used to read the file for planet info
     * 
     * @param fileName
     * @return the array of planets
     * @throws FileNotFoundException
     * @throws ParseException
     * @throws SpaceColonyDataException
     */
    @SuppressWarnings("unused")
    private Planet[] readPlanetFile(String fileName)
        throws FileNotFoundException,
        ParseException,
        SpaceColonyDataException {
        Planet[] planets = new Planet[ColonyCalculator.NUM_PLANETS + 1];
        Scanner file = new Scanner(new File(fileName));
        // keep track of number planets
        int j = 1;
        for (int i = 0; i < ColonyCalculator.NUM_PLANETS && file
            .hasNextLine(); i++) {
            String[] split = file.nextLine().split(", *");
            if (split.length != 5) {
                throw new ParseException(fileName, i);
            }
            // skills are in index 1-3
            else if (!isInSkillRange(Integer.valueOf(split[1]), Integer.valueOf(
                split[2]), Integer.valueOf(split[3]))) {
                throw new SpaceColonyDataException(
                    "Skills not between 1 and 5");
            }
            planets[i] = new Planet(split[0], Integer.valueOf(split[1]), Integer
                .valueOf(split[2]), Integer.valueOf(split[3]), Integer.valueOf(
                    split[4]));
            // tracker for planets
            j++;

        }
        if (j < ColonyCalculator.NUM_PLANETS) {
            throw new SpaceColonyDataException("Less than 3 planets");
        }
        return planets;
    }


    /**
     * Used to read the file for Person info
     * 
     * @param fileName
     * @return aq - ArrayQueue
     * @throws FileNotFoundException
     * @throws ParseException
     * @throws SpaceColonyDataException
     */
    private ArrayQueue<Person> readQueueFile(String fileName)
        throws FileNotFoundException,
        ParseException,
        SpaceColonyDataException {
        ArrayQueue<Person> aq = new ArrayQueue<Person>();
        Scanner file = new Scanner(new File(fileName));
        while (file.hasNextLine()) {
            String[] split = file.nextLine().split(", *");
            for (int i = 0; i < split.length; i++) {
                // checks for special case
                if (split[i] == "") {
                    throw new ParseException(fileName, i);
                }

            }
            // skills are in index 1-3
            if (!isInSkillRange(Integer.valueOf(split[1]), Integer.valueOf(
                split[2]), Integer.valueOf(split[3]))) {
                throw new SpaceColonyDataException(
                    "Skills are not between 1 and 5");
            }
            // no pref
            if (split.length == 4) {
                aq.enqueue(new Person(split[0], Integer.valueOf(split[1]),
                    Integer.valueOf(split[2]), Integer.valueOf(split[3]), ""));
            }
            // pref
            else {
                aq.enqueue(new Person(split[0], Integer.valueOf(split[1]),
                    Integer.valueOf(split[2]), Integer.valueOf(split[3]),
                    split[4]));
            }

        }
        return aq;
    }

}
