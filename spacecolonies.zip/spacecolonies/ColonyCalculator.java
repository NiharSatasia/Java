// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

// import java.util.Arrays;
import list.AList;

/**
 * This class does the major calaculations for the program
 * 
 * @author Nihar Sarasia (niharsatasia)
 * @version 11.10.21
 *
 */
public class ColonyCalculator {
    // ~ Fields ................................................................
    /**
     * Sets the number of planets to 3.
     */
    public static final int NUM_PLANETS = 3;
    /**
     * Sets the minimum skill level to 1.
     */
    public static final int MIN_SKILL_LEVEL = 1;
    /**
     * Sets the maximum skill level to 5.
     */
    public static final int MAX_SKILL_LEVEL = 5;
    private ArrayQueue<Person> applicantQueue;
    private AList<Person> rejectBus;
    private Planet[] planets;

    /**
     * Default constructor for ColonyCalculator.
     * 
     * @param queue
     *            - ArrayQueue.
     * @param planet
     *            - Array.
     */
    public ColonyCalculator(ArrayQueue<Person> queue, Planet[] planet) {
        if (queue == null) {
            throw new IllegalArgumentException();
        }
        this.planets = planet;
        this.applicantQueue = queue;
        this.rejectBus = new AList<Person>();
    }


    /**
     * Gets the ArrayQueue.
     * 
     * @return applicantQueue - elements in queue.
     */
    public ArrayQueue<Person> getQueue() {
        return applicantQueue;
    }


    /**
     * Gets the planet array
     * 
     * @return planets - in an array.
     */
    public Planet[] getPlanets() {
        return planets;
    }


    /**
     * Gets the integer representation for a given planet
     * 
     * @param planet
     *            - the planet that is used to find the index.
     * @return -1 if the string is not a planet.
     */
    public int getPlanetIndex(String planet) {
        int index = -1;
        for (int i = 0; i < NUM_PLANETS; i++) {
            if (planet.equals(planets[i].getName())) {
                index = i;
            }
        }
        return index;
    }


    /**
     * Helper method for getPlanetForPerson
     * 
     * @param nextPerson
     *            - person looking to be sent.
     * @return null or the planet with highest cap.
     */
    private Planet getHighestCapacityPlanet(Person nextPerson) {
        Planet[] temp = planets.clone();
        // Planet[] temp = Arrays.copyOf(planets, planets.length);
        // Arrays.sort(temp);
        Planet hCap = new Planet("", 0, 0, 0, 0);
        for (int i = 0; i < NUM_PLANETS; i++) {
            if (!temp[i].isFull() && temp[i].isQualified(nextPerson)) {
                hCap = temp[i];
            }
        }
        if (hCap.getAvailability() == 0) {
            return null;
        }
        return hCap;

    }


    /**
     * Determines if the next applicant's preference
     * 
     * @param nextPerson
     *            - person who's preference we are trying to find.
     * @return the person's planet
     */
    public Planet getPlanetForPerson(Person nextPerson) {
        if (nextPerson == null || nextPerson.getPlanetPreference() == null
            || NUM_PLANETS == 0) {
            return null;
        }
        int want = getPlanetIndex(nextPerson.getPlanetPreference());
        if (want != -1) {
            // pref
            if (canAccept(planets[want], nextPerson)) {
                return planets[want];
            }
            else {
                return null;
            }
        }
        // no pref
        Planet planet = getHighestCapacityPlanet(nextPerson);
        return planet;
    }


    /**
     * Helper method for accept.
     * 
     * @param planet
     *            - planet in consideration
     * @param person
     *            - person in consideration
     * @return whether or not the queue is empty.
     */
    private boolean canAccept(Planet planet, Person person) {
        return !planet.isFull() && planet.isQualified(person);
    }


    /**
     * This determines if the next applicant can be accepted.
     * 
     * @return The planet to be sent to.
     */
    public boolean accept() {
        if (applicantQueue.isEmpty()) {
            return false;
        }
        Planet send = getPlanetForPerson(applicantQueue.getFront());
        if (send == null) {
            return false;
        }
        return send.addPerson(applicantQueue.dequeue());
    }


    /**
     * Dequeue from queue and remove person from line
     * and adds them to AList represented by rejectBus
     */
    public void reject() {
        if (!applicantQueue.isEmpty()) {
            rejectBus.add(applicantQueue.dequeue());
        }
    }

}
