// Virginia Tech Honor Code Pledge:
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package spacecolonies;

/**
 * This class extends Exception
 * to pass an exception as a string.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 11.10.21
 *
 */

@SuppressWarnings("serial")
public class SpaceColonyDataException extends Exception {
    /**
     * Constructor that calls super and passes it the
     * string message
     * 
     * @param exception
     *            - the exception being passed.
     */
    public SpaceColonyDataException(String exception) {
        super(exception);
    }

}
