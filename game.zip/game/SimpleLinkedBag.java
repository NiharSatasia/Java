// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package game;


import bag.Node;
import bag.SimpleBagInterface;
import student.TestableRandom;

//-------------------------------------------------------------------------
/**
* This class implements SimpleBagInterface in order
* to override certain methods to be able to use a 
* SimpleLinkedBag
* 
* @param <T>
* 
* @author Nihar Satasia (niharsatasia)
* @version 10.04.21
*/
public class SimpleLinkedBag<T> implements SimpleBagInterface<T> 
{
    
 // ~ Fields ................................................................
    private Node<T> firstNode;
    private int numberOfEntries;
    
    /**
     * Constructor that sets the first node to null
     * and sets numberOfEntries to 0
     */
    public SimpleLinkedBag()
    {
        // Initiating firstNode and numberOfEntries.
        firstNode = null;
        numberOfEntries = 0;
    }

 // ~ Methods ...............................................................

    /**
     * Method that adds an entry to the linked bag
     * @param anEntry
     * @return true or false
     */
    @Override
    public boolean add(T anEntry) 
    {
        if (anEntry == null)
        {
            return false;
        }
        // Add to beginning of chain
        Node<T> node1 = new Node<>(anEntry, firstNode);
        
        // First node is null if chain is empty.
        // node1 is the beginning of the chain.
        firstNode = node1;
        
        numberOfEntries++;
        return true;      
    }
    
    /**
     * Method that returns the size of the bag
     * @return numberOfEntries
     */
    @Override
    public int getCurrentSize() 
    {
        return numberOfEntries;
    }


    /**
     * Method that returns whether the bag is empty or not
     * @return true or false
     */
    @Override
    public boolean isEmpty()
    {
        return numberOfEntries == 0;
    }

    
    /**
     * Method that randomly picks from the bag.
     * @return null or the data of the node that is chosen.
     */
    @Override
    public T pick() 
    {
        if (isEmpty())
        {
            return null;
        }
        else
        {
            // Generating a random number to be index with
            // numberOfEntries as the bound.
            TestableRandom generator = new TestableRandom(); 
            int index = generator.nextInt(numberOfEntries);
            
            // Creates a currentNode to be used, starting at firstNode.
            Node<T> currentNode = firstNode;
            for (int i = 0; i < index; i++)
            {
                // Updates currentNode.
                currentNode = currentNode.getNext();
                
            }
            // Returns the value.
            return currentNode.getData();
        }   
    }
    
    /**
     * Helper method that determines if an entry is in the bag
     * @param anEntry
     * @return currentNode
     */
    private Node<T> getReferenceTo(T anEntry)
    {
        boolean found = false;
        
        // Creates a local Node equal to firstNode.
        Node<T> currentNode = firstNode;
        
        // Continues looping until the entry is found.
        while (currentNode != null && !found)
        {
            if (currentNode.getData().equals(anEntry))
            {
                // found is updated once entry is found.
                found = true;
            }
            else
            {
                // Moves the local node until entry is found.
                currentNode = currentNode.getNext();
            }
        }
        return currentNode;  
    }
    
    /**
     * Method that removes an entry from the bag
     * @param anEntry
     * @return true or false
     */
    @Override
    public boolean remove(T anEntry) 
    {
        // Creates a local Node equal to the currenNode from
        // the getReferenceTo helper method.
        Node<T> localNode = getReferenceTo(anEntry);
        
        // Returns false if the entry can simply not be removed.
        if (getReferenceTo(anEntry) == null)
        {
            return false;
        }
        else
        {
            // Copies the data in firstNode to localNode.
            localNode.setData(firstNode.getData());
            
            // Updates firstNode.
            firstNode = firstNode.getNext();
            
            numberOfEntries--;
        }
        return true;
    }

}
