// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package game;

import student.TestCase;
import student.TestableRandom;

/**
**
 * Test class for SimpleArrayBag.
 * @param <T>
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 10.04.21
 *
 */


public class SimpleArrayBagTest<T> extends TestCase
{
 // ~ Fields ................................................................

    private SimpleArrayBag<String> bag1;
    private SimpleArrayBag<String> bag2;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() 
    {
        bag1 = new SimpleArrayBag<String>();
        bag2 = new SimpleArrayBag<String>();
    }
    
    /**
     * Tests to see if the add method works
     * as intended
     */
    public void testAdd()
    {
        // Test passes if entry is successfully added to bag.
        bag1.add("bag1 entry1");
        assertEquals(1, bag1.getCurrentSize());
        
        bag2.add("bag2 entry1");
        bag2.add("bag2 entry2");
        bag2.add("bag2 entry3");
        bag2.add("bag2 entry4");
        bag2.add("bag2 entry5");
        bag2.add("bag2 entry6");
        bag2.add("bag2 entry7");
        bag2.add("bag2 entry8");
        bag2.add("bag2 entry9");
        bag2.add("bag2 entry10");
        bag2.add("bag2 entry11");
        bag2.add("bag2 entry12");
        bag2.add("bag2 entry13");
        bag2.add("bag2 entry14");
        bag2.add("bag2 entry15");
        
        // Test passes if null does not get added.
        bag2.add(null);
        assertEquals(15, bag2.getCurrentSize());
        
        // Basic tests to see if entries are added.
        bag2.add("bag2 entry16");
        bag2.add("bag2 entry17");
        assertEquals(17, bag2.getCurrentSize());
        bag2.add("bag2 entry18");
        assertEquals(18, bag2.getCurrentSize());
        
        // Tests to see if entry will be added
        //  MAX is exceeded.
        bag2.add("bag2 entry19");
        assertEquals(18, bag2.getCurrentSize());
        
    }
    
    /**
     * Tests to see if the getCurrentSize
     * method works as intended
     */
    public void testGetCurrentSize()
    {
        // Tests size after an entry is added.
        bag1.add("bag1 entry1");
        assertEquals(1, bag1.getCurrentSize());
        
        // Tests size after an entry is removed.
        bag1.remove("bag1 entry1");
        assertEquals(0, bag1.getCurrentSize());
    }
    
    /**
     * Tests to see if the isEmpty method works
     * as intended
     */
    public void testIsEmpty()
    {
        // Tests a completely empty bag.
        assertTrue(bag1.isEmpty());
        
        // Tests a non empty bag.
        bag1.add("bag1 entry1");
        assertFalse(bag1.isEmpty());
    }
    
    /**
     * Tests to see if the pick method works
     * as intended
     */
    public void testPick()
    {
        // Test passes since nothing can be picked from
        // an empty bag.
        assertNull(bag1.pick());
        
        bag1.add("bag1 entry1");
        bag1.add("bag1 entry2");
        bag1.add("bag1 entry3");
        bag1.add("bag1 entry4");
        bag1.add("bag1 entry5");
        bag1.add("bag1 entry6");
        
        // Controlling the random integer and then
        // testing to see the right entry is picked
        TestableRandom.setNextInts(1);
        assertEquals("bag1 entry2", bag1.pick());    
        TestableRandom.setNextInts(3);
        assertEquals("bag1 entry4", bag1.pick());        
        TestableRandom.setNextInts(5);
        assertEquals("bag1 entry6", bag1.pick());

    }
    
    /**
     * Tests to see if the remove method works
     * as intended
     */
    public void testRemove()
    {
        bag1.add("bag1 entry1");
        bag1.add("bag1 entry2");
        bag1.add("bag1 entry3");
        bag1.add("bag1 entry4");
        bag1.add("bag1 entry5");
        bag1.add("bag1 entry6");
        
        // Only way it can be false is if getIndexOf returns -1
        assertFalse(bag1.remove("bag1 entry7"));
        
        // Tests to see if entry is properly removed
        assertTrue(bag1.remove("bag1 entry3"));
        assertEquals(5, bag1.getCurrentSize());
        
        bag2.add("bag2 entry1");
        bag2.add("bag2 entry2");
        bag2.add("bag2 entry3");
        bag2.add("bag2 entry4");
        bag2.add("bag2 entry5");
        bag2.add("bag2 entry6");
        
        // Tests to see if entry is properly removed
        assertTrue(bag2.remove("bag2 entry3"));
        assertEquals(5, bag2.getCurrentSize());
        
        // Controlling random integer and picking from the index
        // to see if remove properly updated the order of the bag
        // (no hole in bag).
        TestableRandom.setNextInts(2);
        assertEquals("bag2 entry6", bag2.pick());
        
        // Testing the removal of the same entry twice.
        bag2.remove("bag2 entry1");
        assertFalse(bag2.remove("bag2 entry1"));
        assertFalse(bag2.remove(null));
        
        // Testing the removal of every entry.
        bag2.remove("bag2 entry2");
        bag2.remove("bag2 entry4");
        bag2.remove("bag2 entry5");
        bag2.remove("bag2 entry6");
        assertNull(bag2.pick());
        
        
        
    }

}
