// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package game;

import student.TestCase;
import student.TestableRandom;

/**
**
 * Test class for SimpleLinkedBag.
 * @param <T>
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 10.04.21
 *
 */

public class SimpleLinkedBagTest<T> extends TestCase 
{
 // ~ Fields ................................................................
    private SimpleLinkedBag<String> bag1;
    private SimpleLinkedBag<String> bag2;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp()
    {
        bag1 = new SimpleLinkedBag<String>();
        bag2 = new SimpleLinkedBag<String>();
    }
    
    /**
     * Tests to see if the add method works
     * as intended.
     */
    public void testAdd()
    {
        // Tests passe if entry is added
        assertTrue(bag1.add("b1 e1"));
        assertEquals(1, bag1.getCurrentSize());
        
        // Tests pass if entry is not added
        // as the method should not add a null.
        assertFalse(bag2.add(null));
        assertEquals(0, bag2.getCurrentSize());
    }
    
    /**
     * Tests to see if the getCurrentSize method works
     * as intended.
     */
    public void testGetCurrentSize()
    {
        // Test passes if bag size is properly updated.
        bag1.add("b1 e1");
        bag1.add("b1 e2");
        assertEquals(2, bag1.getCurrentSize());
    }
    
    /**
     * Tests to see if the isEmpty method works
     * as intended.
     */
    public void testIsEmpty()
    {
        // Testing to see if an empty bag is empty.
        assertTrue(bag1.isEmpty());
        bag1.add("b1 e1");
        
        // Testing to see if a non empty bag is empty.
        assertFalse(bag1.isEmpty());
    }
    
    /**
     * Tests to see if the pick method works
     * as intended.
     */
    public void testPick()
    {
        // Test passes since bag is empty.
        assertNull(bag1.pick());
        
        // Controlling the randomly generated integer.
        TestableRandom.setNextInts(1);  
        
        bag1.add("b1 e1");
        bag1.add("b1 e2");
        bag1.add("b1 e3");
        
        // Using the randomly generated integer to make
        // sure the right entry is picked.
        assertEquals("b1 e2", bag1.pick());
    }
    
    /**
     * Tests to see if the remove method works
     * as intended.
     */
    public void testRemove()
    {
        bag1.add("b1 e1");
        bag1.add("b1 e2");
        bag1.add("b1 e3");
        
        // Tests to see if removing an entry from a
        // non empty bag works.
        assertTrue(bag1.remove("b1 e2"));
        assertEquals(2, bag1.getCurrentSize());
        bag1.remove("b1 e3");
        assertEquals(1, bag1.getCurrentSize());
        
        // Tests removing entries that are not in the bag.
        assertFalse(bag1.remove(null));
        assertFalse(bag1.remove("b1, e3"));
        
        
    }

}
