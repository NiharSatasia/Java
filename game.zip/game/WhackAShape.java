// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)


package game;

import bag.SimpleBagInterface;
import cs2.Button;
import cs2.CircleShape;
import cs2.Shape;
import cs2.SquareShape;
import cs2.TextShape;
import cs2.Window;
import cs2.WindowSide;
import student.TestableRandom;
import java.awt.*;

//-------------------------------------------------------------------------
/**
* This class implements methods bottom up in order
* to display a window with various shapes
* that are interactive with the user
* 
* @author Nihar Satasia (niharsatasia)
* @version 10.04.21
*/
public class WhackAShape
{
 // ~ Fields ................................................................
    private SimpleBagInterface<Shape> bag;
    private Window window;
    private TestableRandom randomGenerator;
    
    // ~ Methods ...............................................................

    /**
     * Method that constructs the shapes based on the
     * input.
     * The size, width, and height are all randomly generated.
     * @param input
     * @return currentShape
     */
    public Shape buildShape(String input)
    {
        // Generates a random number from 0-100 inclusive and adds
        // 100 to get a number between 100-200.
        randomGenerator = new TestableRandom(); 
        int size = randomGenerator.nextInt((101)) + 100;
        
        // Subtracting size so the shapes do not hang off the
        // edge of the window.
        int x = randomGenerator.nextInt(window.getGraphPanelWidth() - size);
        int y = randomGenerator.nextInt(window.getGraphPanelHeight() - size);
        
        // Chain of if-else statements to determine the correct shape.
        if (input.contains("red") && input.contains("circle"))
        {     
            CircleShape currentShape = new CircleShape(x, y, size, Color.red);
            currentShape.onClick(this, "clickedShape");
            return currentShape;
        }
        else if (input.contains("red") && input.contains("square"))
        {     
            SquareShape currentShape = new SquareShape(x, y, size, Color.red);
            currentShape.onClick(this, "clickedShape");
            return currentShape;
        }
        else if (input.contains("blue") && input.contains("circle"))
        {     
            CircleShape currentShape = new CircleShape(x, y, size, Color.blue);
            currentShape.onClick(this, "clickedShape");
            return currentShape;
        }
        else if (input.contains("blue") && input.contains("square"))
        {     
            SquareShape currentShape = new SquareShape(x, y, size, Color.blue);
            currentShape.onClick(this, "clickedShape");
            return currentShape;
        }
        else 
        {
            // Throws this exception if the input is npt correct.
            throw new IllegalArgumentException("your input is wrong");
        }
    }
    
    
    /**
     * Method that triggers when a shape is clicked.
     * @param shape
     * 
     */
    public void clickedShape(Shape shape)
    {
        // Removes the shape being clicked.
        window.removeShape(shape);
        bag.remove(shape);
        
        // Randomly picks a shape from the bag.
        Shape nextShape = bag.pick();
        if (nextShape == null)
        {
            // Game over if the shape is null.
            TextShape win = new TextShape(window.getGraphPanelWidth()/2,
                window.getGraphPanelHeight()/2, "You Win!");
            window.addShape(win);
        }
        else
        {
            // Displays the new shape on the window.
            window.addShape(nextShape);
        }
    }
    
    /**
     * Method that triggers when the quit button
     * is clicked.
     * @param button
     */
    public void clickedQuit(Button button)
    {
        System.exit(0);
    }
    
    /**
     * Method that returns the window that is displayed.
     * @return
     */
    public Window getWindow()
    {
        return window;
    }
    
    /**
     * Method that returns the bag being used.
     * @return
     */
    public SimpleBagInterface<Shape> getBag()
    {
        return bag;
    }
    
    // ~ Constructors ...............................................................

    /**
     * Constructor that initializes the fields and quit
     * button. Also adds items to the bag.
     */
    public WhackAShape()
    {
        // Initializing the bag as a SimpleArray.
        bag = new SimpleArrayBag<Shape>();
        window = new Window();
        
        //Initializing the quit button.
        Button quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        // Adds the quit button to the east of the window.
        window.addButton(quitButton, WindowSide.EAST);
        
        // Creating a string of all the possible shapes.
        String[] shapes = new String[]
            {"red circle", "red square", "blue circle", "blue square"};
        
        // Randomly generates a number from 0-8 inclusive
        // then adds 6 to be from 0-8 inclusive.
        randomGenerator = new TestableRandom();
        int bagSize = randomGenerator.nextInt(9) + 6;
        
        // Keeps adding random shapes until the bag size is reached.
        for (int i = 0; i < bagSize; i++)
        {
            Shape stringShape = buildShape(shapes[randomGenerator.nextInt(shapes.length)]);
            bag.add(stringShape);
        }
        
        // Displays a random shape that is picked from the bag.
        window.addShape(bag.pick());
        
    }
    
    /**
     * Constructor that initializes the fields and quit
     * button. Also adds inputed items to the bag.
     * @param inputs
     */
    public WhackAShape(String[] inputs)
    {
        // Initializing the bag as a SimpleArray.
        bag = new SimpleArrayBag<Shape>();
        window = new Window();
        
        //Initializing the quit button.
        Button quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        // Adds the quit button to the east of the window.
        window.addButton(quitButton, WindowSide.EAST);
        
        try
        {
            for (int i = 0; i < inputs.length; i++)
            {
                // Converts the strings to shapes.
                bag.add(buildShape(inputs[i]));
            }
            // Displays a shape to the window.
            window.addShape(bag.pick());
        }
        // IllegalArgumentException if the elements in inputs
        // do not correspond to a shape.
        catch (IllegalArgumentException e)
        {
            e.printStackTrace();
        }
    }


}

