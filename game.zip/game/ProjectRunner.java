// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package game;

/**
 * Used to demonstrate the functionality of WhackAShape.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 10.04.21
 *
 */

public class ProjectRunner {
    /**
     * New instance of WhackAShape and WhackAShape(String[] inputs)
     * 
     * Used to open the GUI through run configurations.
     */
    public static void main(String[] args)
    {
        // Runs the GUI using the WhackAShape constructor.
        WhackAShape WAS = new WhackAShape();
        
        // Runs the GUI using the WhackAShape(String[] inputs) constructor.
        //args = new String[]
           // {"red circle", "red square", "blue circle", "blue square"};
        //WhackAShape WAS2 = new WhackAShape(args);
    }
}
