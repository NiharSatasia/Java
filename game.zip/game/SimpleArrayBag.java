// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package game;
import bag.SimpleBagInterface;
import student.TestableRandom;


//-------------------------------------------------------------------------
/**
* This class implements SimpleBagInterface in order
* to override certain methods to be able to use a 
* SimpleArrayBag
* 
* @param <T>
* 
* @author Nihar Satasia (niharsatasia)
* @version 10.04.21
*/
public class SimpleArrayBag<T> implements SimpleBagInterface<T> 
{
// ~ Fields ................................................................
    
    private T[] bag;
    /**
     * This field declares the maximum items 
     * that can be in the bag.
     */
    public static final int MAX = 18;
    private int numberOfEntries;
    
    /**
     * Constructor that creates a T[] bag
     * and sets numberOfEntries to 0
     */
    public SimpleArrayBag()
    {
        //Initializing the bag.
        @SuppressWarnings("unchecked")
        T[] tempbag = (T[]) new Object[MAX];
        bag = tempbag;
        
        //Initializing numberOfEntries
        numberOfEntries = 0;
    }
 // ~ Methods ...............................................................
    
    
    /**
     * Method that adds items to the bag.
     * @param anEntry
     * @return true or false
     */
    @Override
    public boolean add(T anEntry) 
    {
        // Returns false if MAX is exceeded or if the entry is null
        if (numberOfEntries >= MAX || anEntry == (null))
        {
            return false;
        }
        // Sets the final index to the entry and increments
        // numberOfEntries by 1
        bag[numberOfEntries] = anEntry;
        numberOfEntries++;
        return true;
    }


    /**
     * Method that returns the size of the bag.
     * @return numberOfEntries
     */
    @Override
    public int getCurrentSize() 
    {
        return numberOfEntries;
    }


    /**
     * Method that returns whether or not the 
     * bag is empty.
     * @return true or false
     */
    @Override
    public boolean isEmpty() 
    {
        return numberOfEntries == 0;
    }


    /**
     * Method that randomly picks an item 
     * from the bag.
     */
    @Override
    public T pick() 
    {
        // Returns null if isEmpty returns true.
        if (isEmpty())
        {
            return null;
        }
        // Generating random number to be used as an index
        // with numberOfEntries as the bound.
        TestableRandom generator = new TestableRandom(); 
        int index = generator.nextInt(numberOfEntries);
        return bag[index];
    }
    
    /**
     * Private helper method for remove.
     * @param anEntry
     * @return -1 or the index of removal
     */
    private int getIndexOf(T anEntry)
    {
        if (anEntry == null)
        {
            return -1;
        }
        else
        {
            // Loops through until the entry at a certain index
            // equals anEntry.
            for (int index = 0; index < numberOfEntries; index++)
            {
                if (anEntry.equals(bag[index]))
                {
                    return index;
                }
            }
        }
        return -1;
    }


    /**
     * Method that removes a specified entry.
     * @param anEntry
     * @return true or false
     */
    @Override
    public boolean remove(T anEntry) 
    {
        if (getIndexOf(anEntry) == -1)
        {
            return false;
        }
        else
        {
            // Declaring a variable to be used as index.
            int i = getIndexOf(anEntry);
            
            // Setting index of entry to be removed to the last element.
            bag[i] = bag[numberOfEntries - 1];
            
            // Now setting last element to be null since it replaced
            // the removed entry.
            bag[numberOfEntries - 1] = null;
            
            numberOfEntries--;
        }
        return true;
    }

}
