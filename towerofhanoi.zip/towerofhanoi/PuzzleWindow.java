// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import java.awt.Color;
import java.util.Observable;
import java.util.Observer;
import cs2.Button;
import cs2.Shape;
import cs2.Window;
import cs2.WindowSide;

/**
 * Creates the window for the puzzle.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class PuzzleWindow implements Observer
{
    private HanoiSolver game;
    private Shape left;
    private Shape right;
    private Shape middle;
    private Window window;
    public static final int WIDTH_FACTOR = 25;
    public static final int DISK_GAP = 0;
    public static final int DISK_HEIGHT = 10;

    /**
     * Private method using threads.
     */
    private void sleep() 
    {
        try 
        {
            Thread.sleep(500);
        }
        catch (Exception e)
        {
            
        }
    }

    /**
     * Public method using threads.
     * @param button
     */
    public void clickedSolve(Button button) 
    {
        button.disable();
        new Thread() 
        {
            public void run() 
            {
                game.solve();
            }
        } 
        .start();
    }
    
    /**
     * This method updates the front-end, after the back-end
     * has been changed.
     * @param position
     */
    private void moveDisk(Position position)
    {
        Disk currentDisk = game.getTower(position).peek();
        Shape currentPole = null;
        switch (position)
        {
            case LEFT: currentPole = left;
            break;
            case MIDDLE: currentPole = middle;
            break;
            case RIGHT: currentPole = right;
            break;
            case DEFAULT: currentPole = middle;
            break;
        }
        
        int x = currentPole.getX();
        
        int size = game.getTower(position).size();
        int pole = left.getHeight();
        int y = currentPole.getY() + pole - (size *(DISK_HEIGHT));
        
        int height = currentDisk.getHeight() - DISK_HEIGHT;
        int width = currentDisk.getWidth();
        
        currentDisk.moveTo(x - width/2, y - height/2);
    }
    
    /**
     * Accounts for what to do when buttons are clicked
     * @param game
     */
    public PuzzleWindow(HanoiSolver game)
    {
        this.game = game;
        game.addObserver(this);
        
        window = new Window("Tower of Hanoi");
        left = new Shape(150, 200, 5, 100, Color.black);
        middle = new Shape(300, 200, 5, 100, Color.blue);
        right = new Shape(450, 200, 5, 100, Color.red);
        
        for (int i = 0; i < game.disks(); i++)
        {
            game.getTower(Position.LEFT).push(new Disk(WIDTH_FACTOR * (game.disks() - i)));
            window.addShape(game.getTower(Position.LEFT).peek());
            moveDisk(Position.LEFT);
        }
        
        window.addShape(left);
        window.addShape(middle);
        window.addShape(right);
        
        Button solve = new Button("Solve");
        window.addButton(solve, WindowSide.NORTH);
        solve.onClick(this, "clickedSolve");
        
    }
    
    /**
     * Method is automatically called when the game's move
     * method calls notifyObeservers.
     * @param o
     * @param arg
     */
    @Override
    public void update(Observable o, Object arg) 
    {
        if (arg.getClass().equals(Position.class))
        {
            moveDisk((Position)arg);
        }
        sleep();
    }

}
