// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import student.TestCase;
import java.util.EmptyStackException;

/**
 * Test Class for LinkedStack
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 * @param <T>
 */
public class LinkedStackTest<T> extends TestCase 
{

    private LinkedStack<String> stack1;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() 
    {
        stack1 = new LinkedStack<String>();
    }
    
    /**
     * Tests to see if the push method works as intended.
     */
    public void testPush()
    {
        stack1.push("a");
        assertEquals(1, stack1.size());
        assertEquals("a", stack1.peek());
    }
    
    /**
     * Tests to see if the pop method works as intended.
     */
    public void testPop()
    {
        Exception thrown = null;
        try 
        {
            stack1.pop();
        } 
        catch (Exception exception) 
        {
            thrown = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown instanceof EmptyStackException);
        
        stack1.push("a");
        stack1.push("b");
        stack1.push("c");
        assertEquals(stack1.peek(), stack1.pop());
        assertEquals(2, stack1.size());
    }
    
    /**
     * Tests to see if the peek method works as intended.
     */
    public void testPeek()
    {
        Exception thrown = null;
        try 
        {
            stack1.peek();
        } 
        catch (Exception exception) 
        {
            thrown = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown instanceof EmptyStackException);
        
        stack1.push("a");
        assertEquals("a", stack1.peek());
    }
    
    /**
     * Tests to see if the isEmpty method works as intended.
     */
    public void testIsEmpty()
    {
        assertTrue(stack1.isEmpty());
        assertEquals(0, stack1.size());
        
        stack1.push("a");
        assertFalse(stack1.isEmpty());
    }
    
    /**
     * Tests to see if the size method works as intended.
     */
    public void testSize()
    {
        assertEquals(0, stack1.size());
        
        stack1.push("a");
        assertEquals(1, stack1.size());
    }
    
    /**
     * Tests to see if the toString method works as intended.
     */
    public void testToString()
    {
        stack1.push("a");
        stack1.push("b");
        stack1.push("c");
        assertEquals("[c, b, a]", stack1.toString());
    }
    
    /**
     * Tests to see if the clear method works as intended.
     */
    public void testClear()
    {
        stack1.push("a");
        stack1.push("b");
        stack1.push("c");
        assertEquals(3, stack1.size());
        stack1.clear();
        assertEquals(0, stack1.size());
    }
    
    

}
