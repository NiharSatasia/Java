// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import java.awt.Color;
import cs2.Shape;
import student.TestableRandom;


/**
 * This class extends SHape and implements Comparable<Disk>
 * to allow disks to be compared to one another.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 10.19.21
 *
 */
public class Disk extends Shape implements Comparable<Disk>
{
    
    /**
     * Constructor that calls the super() constructor
     * and creates a random background color.
     * @param width - the width of the disk
     *          
     */
    public Disk(int width)
    {
        super(0, 0, width, PuzzleWindow.DISK_HEIGHT);
        TestableRandom random = new TestableRandom();
        Color color = new Color(random.nextInt(256), random.nextInt(256), 
            random.nextInt(256));
        setBackgroundColor(color);
    }
    
    /**
     * Method that compares the widths of two disks
     * @param otherDisk
     * @return The comparison of the widths in a numeric value.
     */
    @Override
    public int compareTo(Disk otherDisk) 
    {
        if (otherDisk == null)
        {
            throw new IllegalArgumentException();
        }
        return (this.getWidth() - otherDisk.getWidth());
    }
    
    /**
     * Method that converts the width into a string.
     * @return Integer.toString(this.getWidth() - which is the
     * integer converted to a string.
     */
    public String toString()
    {
        return Integer.toString(this.getWidth());
    }
    
    /**
     * Method that determines if two disks are equal.
     * @param obj - an object that is compared to the disk.
     * @return True if the two disks are equal.
     * false if they are not.
     */
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (this.getClass().equals(obj.getClass()))
        {
            Disk objDisk = new Disk(((Shape)obj).getWidth());
            return (this.getWidth() == objDisk.getWidth());
        }
        
        return false;
        
    }

}
