// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import student.TestCase;
/**
 * Test class for Disk.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class DiskTest extends TestCase 
{

    private Disk disk1;
    private Disk disk2;
    private Disk disk3;
    private Disk disk4;
    
    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() 
    {
        int d1width = 50;
        disk1 = new Disk(d1width);
        int d2width = 100;
        disk2 = new Disk(d2width);
        int d3width = 50;
        disk3 = new Disk(d3width);
        disk4 = null;
    }
    
    /**
     * Tests to see if the compareTo method works as intended.
     */
    public void testCompareTo()
    {
        Exception thrown = null;
        try 
        {
            disk1.compareTo(null);
        } 
        catch (Exception exception) 
        {
            thrown = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown instanceof IllegalArgumentException);
        
        assertEquals(0, disk1.compareTo(disk1));
        assertEquals(-50, disk1.compareTo(disk2));
        assertEquals(50, disk2.compareTo(disk1));
        assertEquals(0, disk1.compareTo(disk3));
    }
    
    /**
     * Tests to see if the toString method works as intended.
     */
    public void testToString()
    {
        assertEquals("50", disk1.toString());
        assertEquals("100", disk2.toString());
        assertEquals("50", disk3.toString());
    }
    
    /**
     * Tests to see if the equals method works as intended.
     */
    public void testEquals()
    {
        assertTrue(disk1.equals(disk1));
        assertFalse(disk1.equals(disk4));
        assertFalse(disk1.equals(disk2));
        assertTrue(disk1.equals(disk3));
        assertFalse(disk1.equals(new Object()));
        assertFalse(disk1.equals(null));
    }

}
