// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

/**
 * Enumerator used for the tower positions.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public enum Position 
{
    LEFT, MIDDLE, RIGHT, DEFAULT;

}
