// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import java.util.Observable;

/**
 * HanoiSolver represents a Tower of Hanoi puzzle.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class HanoiSolver extends Observable
{
    private Tower left;
    private Tower middle;
    private Tower right;
    private int numDisks;
    
    
    
    /**
     * Constructor that initializes all the fields.
     * @param numDisks - the number of disks.
     */
    public HanoiSolver(int numDisks)
    {
        this.numDisks = numDisks;
        left = new Tower(Position.LEFT);
        middle = new Tower(Position.MIDDLE);
        right = new Tower(Position.RIGHT);
    }
    
    /**
     * Method that returns the number of disks.
     * @return numDisks
     */
    public int disks()
    {
        return numDisks;
    }
    
    /**
     * Method that returns a position depending on the request.
     * @param pos which is the position of the tower
     * @return left, middle, or right
     */
    public Tower getTower(Position pos)
    {
        switch(pos)
        {
            case LEFT: return left; 
            case RIGHT: return right;
            default: return middle;
        }
        
    }
    
    /**
     * Method that returns left, middle, and right as strings.
     * @return s.toString();
     */
    public String toString()
    {
        StringBuilder s = new StringBuilder();
        s.append(left.toString());
        s.append(middle.toString());
        s.append(right.toString());
        return s.toString();
        
    }
    
    /**
     * Private method that executes the specified move.
     * @param source
     * @param destination
     */
    private void move(Tower source, Tower destination)
    {
        if (source.size() >= 1)
        {
            destination.push(source.pop());
            setChanged();
            notifyObservers(destination.position());
        }
    }
    
    /**
     * Private method that uses recursion and invokes
     * the move method in the base case.
     * @param currentDisks
     * @param startPole
     * @param tempPole
     * @param endPole
     */
    private void solveTowers(int currentDisks, Tower startPole,
        Tower tempPole, Tower endPole)
    {
        if (currentDisks == 1)
        {
            move(startPole, endPole);
        }
        else
        {
            solveTowers(currentDisks - 1, startPole, endPole, tempPole);
            move(startPole, endPole);
            solveTowers(currentDisks - 1, tempPole, startPole, endPole);
        }
    }
    
    /**
     * Provides solveTowers() the correct parameters
     * (left = start, middle = temp, right = end).
     */
    public void solve()
    {
        solveTowers(numDisks, left, middle, right);
    }

}
