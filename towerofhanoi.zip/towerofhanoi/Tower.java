// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

/**
 * Tower extends LinkedStack<Disk> with the intent of pushing
 * smaller disks onto larger ones.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class Tower extends LinkedStack<Disk>
{
    private Position position;
    
    /**
     * Calls the super constructor and stores the tower's position.
     * @param position which is the tower's position.
     */
    public Tower(Position position)
    {
        super();
        this.position = position;
    }
    
    /**
     * Returns the tower's position.
     * @return position
     */
    public Position position()
    {
        return position;
    }
    
    /**
     * Pushes a smaller disk on top of larger ones.
     * @param disk
     */
    @Override
    public void push(Disk disk)
    {
        
        if (this.size() > 0 && this.peek().compareTo(disk) <= 0)
        {
            throw new IllegalStateException();
        }
        else
        {
            super.push(disk);
        }
        
    }

}
