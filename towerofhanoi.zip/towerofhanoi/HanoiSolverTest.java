// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import student.TestCase;
/**
 * Test class for Disk.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class HanoiSolverTest extends TestCase 
{
    private HanoiSolver hanoiSolver1;
    private HanoiSolver hanoiSolver2;
    private HanoiSolver hanoiSolver3;
    private Disk disk1;
    private Disk disk2;
    private Disk disk3;
    
    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() 
    {
        int numdisks1 = 6;
        hanoiSolver1 = new HanoiSolver(numdisks1);
        hanoiSolver2 = new HanoiSolver(numdisks1);
        hanoiSolver3 = new HanoiSolver(numdisks1);
        int d1w = 10;
        disk1 = new Disk(d1w);
        int d2w = 20;
        disk2 = new Disk(d2w);
        int d3w = 30;
        disk3 = new Disk(d3w);
        
    }
    
    /**
     * Tests to see if the disks method works as intended.
     */
    public void testDisks()
    {
        assertEquals(6, hanoiSolver1.disks());
    }
    
    /**
     * Tests to see if the getTower method works as intended.
     */
    public void testGetTower()
    {
        assertEquals(hanoiSolver1.getTower(Position.LEFT).position(), 
            Position.LEFT);
        assertEquals(hanoiSolver1.getTower(Position.MIDDLE).position(), 
            Position.MIDDLE);
        assertEquals(hanoiSolver1.getTower(Position.RIGHT).position(), 
            Position.RIGHT);
    }
    
    /**
     * Tests to see if the toString method works as intended.
     */
    public void testToString()
    {
        hanoiSolver1.getTower(Position.LEFT).push(disk3);
        hanoiSolver1.getTower(Position.LEFT).push(disk2);
        hanoiSolver1.getTower(Position.LEFT).push(disk1);
        assertEquals("[10, 20, 30][][]", hanoiSolver1.toString());
        
        hanoiSolver2.getTower(Position.MIDDLE).push(disk3);
        hanoiSolver2.getTower(Position.MIDDLE).push(disk2);
        hanoiSolver2.getTower(Position.MIDDLE).push(disk1);
        assertEquals("[][10, 20, 30][]", hanoiSolver2.toString());
        
        hanoiSolver3.getTower(Position.RIGHT).push(disk3);
        hanoiSolver3.getTower(Position.RIGHT).push(disk2);
        hanoiSolver3.getTower(Position.RIGHT).push(disk1);
        assertEquals("[][][10, 20, 30]", hanoiSolver3.toString());
        
    }
    
    /**
     * Tests to see if the solve method works as intended.
     */
    public void testSolve()
    {
        hanoiSolver1.getTower(Position.LEFT).push(disk3);
        hanoiSolver1.getTower(Position.LEFT).push(disk2);
        hanoiSolver1.getTower(Position.LEFT).push(disk1);
        assertEquals(3, hanoiSolver1.getTower(Position.LEFT).size());
        
        hanoiSolver1.solve();
        assertEquals(3, hanoiSolver1.getTower(Position.RIGHT).size());
    }

}
