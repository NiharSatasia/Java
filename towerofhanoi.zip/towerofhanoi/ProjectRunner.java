// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

/**
* Used to demonstrate the functionality of Tower of Hanoi.
* 
* @author Nihar Satasia (niharsatasia)
* @version 10.18.21
*
*/

public class ProjectRunner 
{
   public static void main(String[] args)
   {
       int disks = 6;
       if (args.length == 1)
       {
           disks = Integer.parseInt(args[0]);
       }
       
       HanoiSolver hanoi = new HanoiSolver(disks);
       @SuppressWarnings("unused")
       PuzzleWindow window = new PuzzleWindow(hanoi);
   }
}

