// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import student.TestCase;
/**
 * Test class for Tower.
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 */
public class TowerTest extends TestCase 
{

    private Tower tower1;
    private Tower tower2;
    private Tower tower3;
    private Disk disk1;
    private Disk disk2;
    
    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() 
    {
        tower1 = new Tower(Position.LEFT);
        tower2 = new Tower(Position.MIDDLE);
        tower3 = new Tower(Position.RIGHT);
        
        int d1w = 50;
        disk1 = new Disk(d1w);
        int d2w = 100;
        disk2 = new Disk(d2w);
    }
    
    /**
     * Tests to see if the position method works as intended.
     */
    public void testPosition()
    {
        assertEquals(Position.LEFT, tower1.position());
        assertEquals(Position.MIDDLE, tower2.position());
        assertEquals(Position.RIGHT, tower3.position());
    }
    
    /**
     * Tests to see if the push method works as intended.
     */
    public void testPush()
    {
        tower1.push(disk1);
        assertEquals(1, tower1.size());
        
        Exception thrown = null;
        try 
        {
            tower1.push(disk2);
        } 
        catch (Exception exception) 
        {
            thrown = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown instanceof IllegalStateException);
        
        
        
        Exception thrown2 = null;
        try 
        {
            tower1.push(disk1);
        } 
        catch (Exception exception)
        {
            thrown2 = exception;
        }

        // checks whether an Exception was actually thrown
        assertNotNull(thrown2);

        // checks whether the right type of Exception was thrown
        assertTrue(thrown2 instanceof IllegalStateException);
    }

}
