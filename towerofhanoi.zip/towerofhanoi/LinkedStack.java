// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)
package towerofhanoi;

import java.util.EmptyStackException;
import stack.StackInterface;

/**
 * LinkedStack that implements StackInterface
 * @author Nihar Satasia (niharsatasia)
 * @version 10.18.21
 *
 * @param <T>
 */
public class LinkedStack<T> implements StackInterface<T>
{
    private Node<T> topNode;
    private int size;
    
    /**
     * LinkedStack default constructor.
     */
    public LinkedStack()
    {
        topNode = null;
        size = 0;
    }
    

    /**
     * Empties the stack.
     */
    @Override
    public void clear() 
    {
        topNode = null;
        size = 0;
    }

    /**
     * Determines if the stack is empty.
     * @return T is if is empty, F is if isn't.
     */
    @Override
    public boolean isEmpty() 
    {
        return size == 0;
    }

    /**
     * Gets the data of the topNode.
     * @return the value of topNode.
     */
    @Override
    public T peek() 
    {
        if (isEmpty())
        {
            throw new EmptyStackException();
        }
        else
        {
            return topNode.getData();
        }
       
    }

    /**
     * Removes the topNode.
     * @return the element removed.
     */
    @Override
    public T pop() 
    {
        if (isEmpty())
        {
            throw new EmptyStackException();
        }
        T top = peek();
        topNode = topNode.getNextNode();
        size--;
        return top;
    }

    /**
     * Adds a new Node to the stack.
     */
    @Override
    public void push(T newEntry) 
    {
        topNode = new Node<T>(newEntry, topNode);
        size++;
    }
    
    /**
     * Determines the size of the stack.
     * @return size.
     */
    public int size()
    {
        return size;
    }
    
    /**
     * Prints out the stack as an array.
     * @return s.
     */
    public String toString()
    {
        StringBuilder s = new StringBuilder();
        s.append("[");
        Node<T> p = topNode;
        while (p != null)
        {
            if (s.length() > 1)
            {
                s.append(", ");
            }
            s.append(p.getData().toString());
            p = p.getNextNode();
        }
        s.append("]");
        return s.toString();
    }
    
    
    /**
     * New inner private Node class that are singly linked.
     * @author Nihar Satasia (niharsatasia)
     * @version 10.18.21
     *
     * @param <T>
     */
    @SuppressWarnings("hiding")
    private class Node<T>
    {
        private Node<T> next;
        private T data;
        
        
        /**
         * Constructor that sets data and next immediately.
         * @param data
         */
        public Node(T data) 
        {
            this.data = data;
            //this.next = null;
        }
        
        /**
         * Constructor that initializes entry and node.
         * @param entry
         * @param node
         */
        public Node(T entry, Node<T> node) 
        { 
            this(entry); 
            this.setNextNode(node);
        }
        
        /**
         * Gets the next node.
         * @return next.
         */
        public Node<T> getNextNode()
        {
            return next;
        }
        
        /**
         * Gets the data of the node.
         * @return data.
         */
        public T getData()
        {
            return data;
        }
        /**
         * Sets the current node to the next node.
         * @param newNext
         */
        public void setNextNode(Node<T> newNext)
        {
            next = newNext;
        }
    }

}
