// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package project1;

/**
 * Used to demonstrate the functionality of both
 * ShapeWindow and DisplayCollection classes.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 09.14.21
 *
 */
public class ProjectRunner {
    // ~ main method ...........................................................
    
    /**
     * New instance of DisplayCollection and ShapeWindow class.
     * 
     * Used to open the GUI through run configurations.
     */
    public static void main(String[] args)
    {
        DisplayCollection dc = new DisplayCollection();
        ShapeWindow window = new ShapeWindow(dc.getItemBag());
    }

}
