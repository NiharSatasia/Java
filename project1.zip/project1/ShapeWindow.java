// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package project1;

import bag.BagInterface;
import cs2.TextShape;
import cs2.Window;
import cs2.Button;
import cs2.WindowSide;
import java.awt.Color;


/**
 * Contains the Graphical User Interface functionality.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 09.14.21
 *
 */

public class ShapeWindow {
    
    // ~ Fields ................................................................
    private Window window;
    private TextShape textShape;
    private Button quitButton;
    private Button chooseButton;
    BagInterface <String> itemBag;

    // ~ Constructor ...........................................................
    /**
     * Creates objects of Window, Button, and TextShape.
     */
    public ShapeWindow(BagInterface <String> itemBag)
    {
        window = new Window();
        window.setTitle("Project 1");
        this.itemBag = itemBag;
        
        quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        
        // Adds the quit button to the top of the window.
        window.addButton(quitButton, WindowSide.NORTH);
        
        chooseButton = new Button("Choose");
        chooseButton.onClick(this, "clickedChoose");
        
        // Adds the choose button to the bottom of the window.
        window.addButton(chooseButton, WindowSide.SOUTH);
        
        // Creates the text and its position which will
        // be centered using a method.
        textShape = new TextShape(0,0, " ");
        window.addShape(textShape);
       
    }
    
    // ~ Methods ...............................................................

    // ----------------------------------------------------------
    /**
     * 
     * @param quitButton
     *              button that is used to exit the window
     * closes the window
     */
    public void clickedQuit(Button quitButton)
    {
        System.exit(0);
    }
    
    // ----------------------------------------------------------
    /**
     * 
     * @param clicked Button
     *              button that is used to choose items
     * sets the text on screen to item chosen if bag is not empty
     * implements helper methods colorText() and centerText() 
     */
    public void clickedChoose(Button clickedButton)
    {
        if(itemBag.isEmpty())
        {
            textShape.setText("No more items");
            colorText();
            centerText();
        }
        else
        {
            textShape.setText(itemBag.remove());
            colorText();
            centerText();
        }
        
    }
    
 // ----------------------------------------------------------
    /**
     * 
     * helper method that changes the color of the text
     * depending on if the text contains "red" or "blue".
     *
     */
    public void colorText()
    {
        if(textShape.getText().contains("red"))
        {
            textShape.setForegroundColor(Color.RED);
        }
        else if(textShape.getText().contains("blue"))
        {
            textShape.setForegroundColor(Color.BLUE);
        }
        else
        {
            textShape.setForegroundColor(Color.BLACK);
        }
    }
    
 // ----------------------------------------------------------
    /**
     * 
     * helper method that centers the text   
     * 
     */
    public void centerText()
    {
        // Variables that store the properties of the window.
        int gWidth = window.getGraphPanelWidth();
        int gHeight = window.getGraphPanelHeight();
        
        // Variables that store the properties of the text.
        int width = textShape.getWidth();
        int height = textShape.getHeight();
        
        // gWidth/2 accounts for center of width of panel.
        // width/2 accounts for text's width affecting the overall width.
        textShape.setX(gWidth/2 - width/2);
        
        // gHieght/2 accounts for center of height of panel.
        // height/2 accounts for text's height affecting the overall height.
        textShape.setY(gHeight/2 - height/2);
        
    }
    
 
    
}

