// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package project1;

import bag.Bag;
import bag.BagInterface;
import java.util.Random;

/**
 * Contains the functionality to create a 
 * randomly generated bag.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 09.14.21
 *
 */
public class DisplayCollection {
    
    // ~ Fields ................................................................
    
    /**
     * Creates a constant STRINGS that contains the item options.
     */
    public static final String[] STRINGS = new String[] 
        {"red circle", "blue circle", "red square", "blue square"};
    
    /**
     * Initializes the itemBag field.
     */
    private BagInterface<String> itemBag;
    
    
    // ~ Constructor ...........................................................
    /**
     * New DisplayCollection object.
     */
    public DisplayCollection()
    {
        this.itemBag = new Bag<>();
        Random random = new Random();
        
        //random.nextInt((max-min)+1) + min is used
        //to get a random inclusive number from 5-15.
        int count = random.nextInt((15 - 5) + 1) + 5;
        
        for (int i = count; i > 0; i--)
        {
            //random.nextInt((max-min)+1) + min is used 
            //to get a random string from a random index from STRINGS.
            itemBag.add(STRINGS[random.nextInt((3 - 0) + 1) + 0]);
        }
    }
    
    // ~ Methods ...............................................................
    
    // ----------------------------------------------------------
    /**
     * Gets the itemBag.
     * 
     * @return the bag.
     */
    public BagInterface<String> getItemBag()
    {
        return itemBag;
    }
}
