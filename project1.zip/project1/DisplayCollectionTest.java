// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor
// and integrity at all times.
// I will not lie, cheat, or steal, nor 
// will I accept the actions of those who do.
// -- Nihar Satasia (nihar satasia)

package project1;

import bag.BagInterface;
import student.TestCase;
/**
 * Test class for DisplayCollection.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @version 09.14.21
 *
 */
public class DisplayCollectionTest extends TestCase {
    
    // ~ Fields ................................................................
    
    /**
     * Intentionally left empty.
     */
    public void setUp()
    {
        //Intentionally left empty.
    }
    
    /**
     * Tests to see if the bagSize is between 5 and 15 inclusive.
     */
    public void testBagSize()
    {
        // Creates a new instance of DisplayCollection class.
        DisplayCollection dcTest = new DisplayCollection();
        
        // Stores its bag in a local variable.
        BagInterface<String> bag1 = dcTest.getItemBag();
        
        // Tests pass as long as the size of the bag is between 5-15 inclusive.
        assertTrue(bag1.getCurrentSize() >= 5);
        assertTrue(bag1.getCurrentSize() <= 15);
        
        
        // For loop that runs the same tests but over 20 different bags.
        for (int i = 0; i < 20; i++)
        {
            DisplayCollection dcTest1 = new DisplayCollection();
            BagInterface<String> bag2 = dcTest1.getItemBag();
            assertTrue(bag2.getCurrentSize() >= 5);
            assertTrue(bag2.getCurrentSize() <= 15);
        }
        
    }
    
    /**
     * Tests to see if the bag contains only strings that are in STRINGS.
     */
    public void testBagContents()
    {
        // Creates a new instance of DisplayCollection class.
        DisplayCollection dcTest2 = new DisplayCollection();
        
        // Stores its bag in a local variable.
        BagInterface<String> bag3 = dcTest2.getItemBag();
        
        // For loop that runs through the bag size and determines
        // which test is needed depending on item removed.
        for (int i = 0; i < bag3.getCurrentSize(); i++)
        {
            String remove1 = bag3.remove();
            if (remove1.equals("blue square"))
            {
                assertTrue(remove1.equals("blue square"));
            }
            else if (remove1.equals("red square"))
            {
                assertTrue(remove1.equals("red square"));
            }
            else if (remove1.equals("blue circle"))
            {
                assertTrue(remove1.equals("blue circle"));
            }
            else if (remove1.equals("red circle"))
            {
                assertTrue(remove1.equals("red circle"));
            }
            else
            {
                //Test will fail if any of the items 
                //are not red/blue circle/square.
                assertTrue(remove1.equals("red circle"));
            }
            
        }
    }

}
