package prj1;

/**
 * 
 * This class was the edge class used to represent the edges in 
 * dijkstra's algorithm
 * 
 * @author Will Zaccaria and Nihar Satasia
 * 
 *
 */
public class edge {

    private int source;
    private int dest;
    private int weight;
    
    /**
     * Constructor
     * 
     * @param source
     * @param dest
     * @param weight
     */
    public edge(int source, int dest, int weight)
    {
        this.source = source;
        this.dest = dest;
        this.weight = weight;
    }
    
    /**
     * 
     * @return source
     */
    public int getSource()
    {
        return this.source;
    }
    
    /**
     * 
     * @return dest
     */
    public int getDest()
    {
        return this.dest;
    }
    
    /**
     * 
     * @return weight
     */
    public int getWeight()
    {
        return this.weight;
    }
    
}
