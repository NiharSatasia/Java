package prj1;

import java.util.ArrayList;
/**
 * The implementation of Dijkstras shortest path algorithm by using a simple
 * linear search to find the unvisited node with the minimum distance estimate
 * 
 * @author William Zaccaria and Nihar Satasia
 * @version 1.1
 */
public class DijkstrasWithoutHeap {


    private int[] distArray;
    private boolean[] visitedArray;
    private ArrayList<edge>[] adList;
    /**
     * Constructor of the class
     * 
     * @param n:
     *            number of nodes of the graph
     * @param edges:
     *            the set of edges of the graph. Each row of 'edges' is in the
     *            form of [u, v, w], which means that there is an edge between u
     *            and v with weight w. So edges[i][0] and edges[i][1] are the
     *            end-points of the i-th edge and edges[i][2] is its weight
     */
    public DijkstrasWithoutHeap(int n, int[][] edges) {
        // TODO complete
        //initializing distance and visited arrays
        this.distArray = new int[n];
        this.visitedArray = new boolean[n]; 
        
        //initializing the adjacency list
        this.adList = new ArrayList[n+1];
        for (int i = 0; i < n+1; i++)
        {
            adList[i] = new ArrayList<edge>();
        }
        for (int i = 0; i < n; i++)
        {
            distArray[i] = Integer.MAX_VALUE;
            visitedArray[i] = false;
        }
        //storing edges in the adjacency list
        for (int i = 0; i < edges.length; i++)
        {
            int u = edges[i][0];
            int v = edges[i][1];
            int w = edges[i][2];
            
            //this.edge = new edge(u,v,w);
            adList[u].add(new edge(u,v,w));
            adList[v].add(new edge(v,u,w));
        }
    }


    /**
     * This method computes and returns the distances of all nodes of the graph
     * from the source node
     * 
     * @param source
     * 
     * @return an array containing the distances of the nodes of the graph from
     *         source. Element i of the returned array represents the distance
     *         of node i from the source
     */
    public int[] run(int source) {
        // TODO Complete
        distArray[source-1] = 0;
        visitedArray[source-1] = true;
        //int j = 0;
        //int minDist = Integer.MAX_VALUE;
        int next = source;
        int nextDist = 0;
        while(nextDist != Integer.MAX_VALUE) //does not end
        {
            
            int n = 0;
            int neighbor = -1;
            int node = -1;
            int nodeWeight = -1;
            int newDistance = -1;
            int compare = -1;
            
            /*
             * this for loop iterates through the neighbors
             */
            for(int i = 0; i < adList[next].size(); i++)
            {
                neighbor = adList[next].get(i).getDest();
                node = adList[next].get(i).getSource();
                nodeWeight = adList[next].get(i).getWeight();
                
                newDistance = distArray[node-1] + nodeWeight;
                compare = distArray[neighbor-1];
                /*
                 * this if statement compares the distances of the neighbors and stores
                 * if it is the shortest distance
                 */
                if (newDistance < compare)
                {
                    distArray[neighbor-1] = newDistance; //withheap have to decrease key as well, heap has to have updated distances
                    //visitedArray[node-1] = true;
                    n++;
                    
                }
                
            }
                    
            //System.out.println("    111111");
            
            int nextMin = Integer.MAX_VALUE;
            int nextHold = -1;
            /*
             * This for loop determines the next node to iterate in the graph
             */
            for (int i = 0; i < distArray.length; i++)
            {
                
                if (!visitedArray[i] && distArray[i] < nextMin)
                {
                
                    nextHold = i;
                    nextMin = distArray[i];
                
                
                }
            }
            next = nextHold + 1;
            if (nextHold == -1 )
            {
                break; 
            }
            visitedArray[next -1] = true;       
            /*
             * This if statement determines whether the while loop continues or not
             * n will increase if there are neighbors left to be updated
             * otherwise it will be 0
             */
            /*if (n == 0)
            {
                nextDist = Integer.MAX_VALUE;
            }
            */
        }
        //System.out.println();
        for(int i = 0; i < visitedArray.length; i++)
        {
            if( distArray[i] == Integer.MAX_VALUE)
            {
                distArray[i] = -1;
            }
            
            
        }
        
        return distArray;
    }

}
