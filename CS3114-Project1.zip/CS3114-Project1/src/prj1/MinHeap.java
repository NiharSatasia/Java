package prj1;

//import java.util.ArrayList;

/**
 * In this class, we implement the d-ary min-heap data structure
 * 
 * @author William Zaccaria and Nihar Satasia
 *
 */
public class MinHeap {
    // The parameter d in the d-ary min-heap
    private int d;

    // The array representation of your min-heap (It is not required to use this)
    private HeapNode[] nodes;

    // this parameter keeps track of the heap size.
    private int size;
    /**
     * Constructor
     * 
     * @param n:
     *            maximum number of elements in the min-heap at each time
     * @param d:
     *            parameter d in the d-ary min-heap
     */
    public MinHeap(int n, int d) {
        this.d = d;
        this.nodes = new HeapNode[n];
        this.size = 0;
        
    }


    /**
     * This method inserts a new element with "id" and "value" into the min-heap
     * 
     * @param id
     * @param value
     */
    public void insert(int id, int value) {
        // TODO complete
        HeapNode element = new HeapNode(id, value);
        nodes[size] = element;
        size++;
        //System.out.print(" ins ");
        //System.out.print(value + " - ");
        //System.out.println(toString());
        //add a way to heapify up
        heapifyUp(size-1);
        heapifyDown(1);
        
        //System.out.println(toString());
    }


    /**
     * This method extracts the min value of the heap
     * 
     * @return an array consisting of two integer elements: id of the minimum
     *         element and the value of the minimum element
     * 
     *         So for example, if the minimum element has id = 5 and value = 1,
     *         you should return the array [5, 1]
     */
    public int[] extractMin() {
        // TODO complete
        if (size == 0)
        {
            return null;
        }
        //delete the element at i by moving the n+1 element to i
        int[] min = new int[2];
        min[0] = nodes[0].getId();
        min[1] = nodes[0].getValue();
        //System.out.println(toString());
        swap(0,size-1);
        
        size--;
        
        heapifyDown(0);
        
        nodes[size] = null;
        //heapifyUp(size);
        //System.out.print("ext");
        //System.out.println(toString());
        return min;
        //if element at i is too small, fix heap order 
            //heapify up
        //if element i is too large, fix heap by heapify down.
        
    }


    /**
     * This method takes an id and a new value newValue for the corresponding
     * node, and updates the data structure accordingly
     * 
     * @param id
     * @param newValue
     */
    public void decreaseKey(int id, int newValue) {
        // TODO complete
        //System.out.print("decrease");
        HeapNode[] help = nodes;
        int compare = 0;
        int index = 0;
        int counter = 0;
        for(int i = 0; i < help.length; i++)
        {
            compare = help[i].getId();
            if(id == compare)
            {
                index = i; //sets the location of the equal id to the index
            }
            else
            {
                counter++; //if this counter == help.length-1 than that means the given id is not present
            }
        }
        if (nodes[index].getValue() > newValue) //&& counter != help.length - 1) //confirms that the id exists and the new value is less than the old value.
        {
        nodes[index].setValue(newValue);
        heapifyUp(index);
        heapifyDown(index);
        //heapifyDown(0);
    
        }
        //System.out.println(toString());
    }


    /**
     * This method returns the array representation of heap
     * 
     * @return the array representation of heap
     */
    public int[] getHeap() {
        // TODO complete
        int[] heap = new int[size];
        for(int i = 0; i < size; i++)
        {
            heap[i] = nodes[i].getValue();
        }
        return heap;
    }


    /**
     * the toString method that returns a string with the values of the heap in
     * the array representation.
     * This method can help you find the issues of your code when you want to
     * debug.
     * 
     * @return string form of the array representation of heap
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.nodes.length; i++) {
            if (nodes[i] != null) {
                sb.append(nodes[i].getValue());
                sb.append(' ');
            }
        }
        return sb.toString();
    }
    
    /**
     * 
     * This method moves up the heap and swaps out the nodes that are 
     * out of order
     * 
     * @param i:
     *           this is the current node
     */
    private void heapifyUp(int i)
    {
        int parent = 0;
        if (i != 0)
        {
            parent = (i-1);// / d;
        }
        if (/*parent >= 0 &&*/ nodes[i].getValue() < nodes[parent].getValue())
        {
            //System.out.print("heapup");
            swap(parent, i);
            heapifyUp(parent);
        }
    }
    /**
     * 
     * This method moves down the heap and swaps out the nodes that are
     * out of order
     * 
     * @param i:
     *           this is the current index of the node
     */
    private void heapifyDown(int i)
    {
        int[] children = new int[d];
        for (int j = 0; j<d; j++)
        {
            children[j] = (i * d) + j+1;
        }
        int minChildVal = Integer.MAX_VALUE;
        int minChildInd = -1;
        for (int k = 0; k < children.length; k++)
        {
            if (children[k] < size && nodes[children[k]].getValue() < minChildVal )
            {
                minChildInd = children[k];
                minChildVal = nodes[children[k]].getValue();
            }
        }
        
        if (minChildInd >= 0 && nodes[minChildInd].getValue() < nodes[i].getValue())
        {
            //System.out.print("heapdown");
            
            swap(minChildInd, i);
            heapifyDown(minChildInd);
        }
        
    }
    
    /**
     * 
     * This method swaps the position of two nodes
     * 
     * @param pos1 
     * @param pos2
     */
    private void swap(int pos1, int pos2)
    {
        HeapNode a = nodes[pos1];
        nodes[pos1] = nodes[pos2];
        nodes[pos2] = a;
    }

}
