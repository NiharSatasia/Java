// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import java.io.FileNotFoundException;
import student.TestCase;

/**
 * Tests CovidReader
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class CovidReaderTest extends TestCase {

    private CovidReader covidReader1;

    /**
     * Set up for all test methods. Runs before every test.
     * 
     * @throws FileNotFoundException
     */
    public void setUp() throws FileNotFoundException {
        covidReader1 = new CovidReader(
            "Cases_and_Deaths_by_race_CRDT_Sep2020.csv");
    }


    /**
     * Tests to see if the output is correct.
     * 
     * @throws FileNotFoundException
     */
    public void testToString() throws FileNotFoundException {
        assertEquals(covidReader1, covidReader1);
    }
}
