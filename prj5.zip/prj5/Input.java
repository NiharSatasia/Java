// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import java.io.FileNotFoundException;

/**
 * Runs the program
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 *
 */
public class Input {
    public static void main(String[] args) throws FileNotFoundException {
        if (args.length == 1) {

            System.out.println(new CovidReader(args[0]));
        }
        else {
            System.out.println(new CovidReader(
                "Cases_and_Deaths_by_race_CRDT_Sep2020.csv").toString());
            
        }
    }

}
