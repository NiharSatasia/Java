// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import cs2.Button;
import cs2.Shape;
import cs2.TextShape;
import cs2.Window;
import cs2.WindowSide;
import java.awt.Color;
import java.text.DecimalFormat;

/**
 * The GUI window class.
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 2021.11.19
 */
public class GUIWindow {
    public static final int BAR_HEIGHT = 10;
    public static final int BAR_GAP = 10;
    public static final int WIDTH_FACTOR = 15;
    private LinkedList<State> storeStates;
    private State state;
    private int count;
    private Window window;
    private Button representDC;
    private Button representGA;
    private Button representMD;
    private Button representNC;
    private Button representTN;
    private Button representVA;
    private Button quit;
    private Button sortByCFR;
    private Button sortByAlpha;

    /**
     * Intializes buttons
     */
    public GUIWindow(LinkedList<State> statesList) {

        storeStates = statesList;

        window = new Window();
        window.setTitle("Covid Visualizer");
        

        representDC = new Button("Represent DC");
        representDC.onClick(this, "clickedRepresentDC");
        window.addButton(representDC, WindowSide.SOUTH);

        representGA = new Button("Represent GA");
        representGA.onClick(this, "clickedRepresentGA");
        window.addButton(representGA, WindowSide.SOUTH);

        representMD = new Button("Represent MD");
        representMD.onClick(this, "clickedRepresentMD");
        window.addButton(representMD, WindowSide.SOUTH);

        representNC = new Button("Represent NC");
        representNC.onClick(this, "clickedRepresentNC");
        window.addButton(representNC, WindowSide.SOUTH);

        representTN = new Button("Represent TN");
        representTN.onClick(this, "clickedRepresentTN");
        window.addButton(representTN, WindowSide.SOUTH);

        representVA = new Button("Represent VA");
        representVA.onClick(this, "clickedRepresentVA");
        window.addButton(representVA, WindowSide.SOUTH);

        quit = new Button("Quit");
        quit.onClick(this, "clickedQuit");
        window.addButton(quit, WindowSide.NORTH);

        sortByCFR = new Button("Sort by CFR");
        sortByCFR.onClick(this, "clickedSortByCFR");
        window.addButton(sortByCFR, WindowSide.NORTH);

        sortByAlpha = new Button("Sort by Alpha");
        sortByAlpha.onClick(this, "clickedSortByAlpha");
        window.addButton(sortByAlpha, WindowSide.NORTH);

    }


    /**
     * Clicked RepresentDC button
     * 
     * @param button
     *            representsDC button
     */
    public void clickedRepresentDC(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(0));

    }


    /**
     * Clicked RepresentGA button
     * 
     * @param button
     *            representsGA button
     */
    public void clickedRepresentGA(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(1));

    }


    /**
     * Clicked RepresentMD button
     * 
     * @param button
     *            representsMD button
     */
    public void clickedRepresentMD(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(2));

    }


    /**
     * Clicked RepresentNC button
     * 
     * @param button
     *            representsNC button
     */
    public void clickedRepresentNC(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(3));
    }


    /**
     * Clicked RepresentTN button
     * 
     * @param button
     *            representsTN button
     */
    public void clickedRepresentTN(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(4));
    }


    /**
     * Clicked RepresentVA button
     * 
     * @param button
     *            representsVA button
     */
    public void clickedRepresentVA(Button button) {
        window.removeAllShapes();
        displayBars(storeStates.get(5));
    }


    /**
     * Clicks quit button
     * 
     * @param button
     *            quit button
     */
    public void clickedQuit(Button button) {
        System.exit(0);
    }


    /**
     * Button for SortByCFR
     * 
     * @param button
     *            sort by CFR button
     */
    public void clickedSortByCFR(Button button) {
        state = storeStates.get(0);
        String stateTitle = window.getTitle();
        String stateName = stateTitle.substring(0, 2);
        for (int i = 0; i <= 5; i++) {
            if (state.getName().equals(stateName)) {
                state = storeStates.get(i);
            }
        }
        state.toStringCFR();
        if (count > 0) {
            window.removeAllShapes();
        }

        displayBars(state);

    }


    /**
     * Button for SortByAlpha
     * 
     * @param button
     *            sort by Alpha button
     */
    public void clickedSortByAlpha(Button button) {
        state = storeStates.get(0);
        String stateTitle = window.getTitle();
        String stateName = stateTitle.substring(0, 2);
        if (count == 0) {
            TextShape text = new TextShape(250, 10, "Pick a State First",
                Color.black);
            window.addShape(text);
        }
        else {
            for (int i = 0; i <= 5; i++) {
                if (storeStates.get(i).getName().equals(stateName)) {
                    state = storeStates.get(i);
                }
            }
            state.toStringAlphabetical();
            if (count > 0) {
                window.removeAllShapes();
            }
            displayBars(state);
        }
    }


    /**
     * Displays all the bars and text
     * 
     * @param state3
     *            state displayed
     */
    public void displayBars(State state3) {
        TextShape printTitle = new TextShape(250, 10, state3.getName()
            + " Case Fatality Ratios by Race", Color.black);
        window.addShape(printTitle);
        window.setTitle(state3.getName());
        int x = 150;
        double height = 0;
        for (int i = 0; i < 5; i++) {
            Race r = state3.getList().get(i);
            double raceCFR = r.covidCalculator();
            DecimalFormat d = new DecimalFormat("#.#");
            String sCFR = d.format(raceCFR);

            if (raceCFR == -1) {
                TextShape t = new TextShape(x, 200, "NA", Color.black);
                window.addShape(t);
            }
            else {
                if (raceCFR > 40) {
                    height = BAR_HEIGHT * (raceCFR / 5);
                }
                else if (raceCFR > 20) {
                    height = BAR_HEIGHT * (raceCFR / 4);
                }
                else if (raceCFR < 1) {
                    height = BAR_HEIGHT * (raceCFR / 4);
                }
                else {
                    height = BAR_HEIGHT * (raceCFR * 2);
                }
                Shape bar = new Shape(x, 200 - (int)height, WIDTH_FACTOR,
                    (int)height, Color.blue);
                window.addShape(bar);
                TextShape printCFR = new TextShape(x - 10, 220, sCFR + "%", Color.black);
                window.addShape(printCFR);
            }
            TextShape printRace = new TextShape(x - 10, 240, r.getName(),
                Color.black);
            window.addShape(printRace);
            x += 100;
        }
        count++;
    }
}
