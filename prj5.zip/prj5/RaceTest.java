// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import student.TestCase;

/**
 * Tests Race
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class RaceTest extends TestCase {

    private Race race1;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        race1 = new Race("a", 10, 4);
    }


    /**
     * Tests getName
     */
    public void testGetName() {
        assertEquals("a", race1.getName());
    }


    /**
     * Tests getCases
     */
    public void testGetCases() {
        assertEquals(10, race1.getCases(), .0000001);
    }


    /**
     * Tests getDeaths
     */
    public void testGetDeaths() {
        assertEquals(4, race1.getDeaths(), .0000001);
    }


    /**
     * Tests covidCalculator
     */
    public void testCovidCalculator() {
        assertEquals(40, race1.covidCalculator(), .0000001);
    }


    /**
     * Tests getCFR
     */
    public void testgetCFR() {
        assertEquals(race1.covidCalculator(), race1.getCFR(), .0000001);
    }


    /**
     * Tests compareCFR
     */
    public void testCompareCFR() {
        Race race2 = new Race("b", 11, 8);
        assertEquals(-1, race1.compareCFR(race2));
        assertEquals(1, race2.compareCFR(race1));
        Race race3 = new Race("c", 11, 8);
        assertEquals(1, race2.compareCFR(race3));
        assertEquals(-1, race3.compareCFR(race2));
    }


    /**
     * Tests compareAlpha
     */
    public void testCompareAlpha() {
        Race race2 = new Race("b", 11, 8);
        assertEquals(-1, race1.compareAlpha(race2));
        assertEquals(1, race2.compareAlpha(race1));
        assertEquals(0, race1.compareAlpha(race1));
    }


    /**
     * Tests toString
     */
    public void testToString() {
        assertEquals("a: 10 cases, 40% CFR ", race1.toString());
    }

}
