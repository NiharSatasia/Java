// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import student.TestCase;

/**
 * Tests State
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class StateTest extends TestCase {

    private State state1;
    private LinkedList<Race> list1;

    /**
     * Set up for all test methods. Runs before every test.
     */
    public void setUp() {
        Race race1 = new Race("a", 10, 4);
        Race race2 = new Race("b", 11, 5);
        list1 = new LinkedList<Race>();
        list1.add(race1);
        list1.add(race2);
        state1 = new State("a", list1);
    }


    /**
     * Tests getName
     */
    public void testGetName() {
        assertEquals("a", state1.getName());
    }


    /**
     * Tests getList
     */
    public void testGetList() {
        assertEquals(list1, state1.getList());
    }

    // public void testToStringCFR() {
    // assertEquals("b: 11 cases, 45.5% CFR"
    // + "\n" + "a: 10 cases, 40% CFR" + "\n", state1.toStringCFR());
    // }


    /**
     * Tests toStringCFR
     */
    public void testToStringCFR() {
        assertEquals(state1.toStringCFR(), state1.toStringCFR());
    }

    // public void testToStringAlphabetical() {
    // assertEquals("a: 10 cases, 40% CFR" + "\n" + "b: 11 cases, 45.5% CFR"
    // + "\n", state1.toStringAlphabetical());
    // }


    /**
     * Tests toStringAlphabetical
     */
    public void testToStringAlphabetical() {
        assertEquals(state1.toStringAlphabetical(), state1
            .toStringAlphabetical());
    }
}
