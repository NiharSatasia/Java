// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Gathers data from the csv file
 * 
 * @author Nihar Satasua (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class CovidReader {

    private LinkedList<State> data;

    /**
     * CovidReader constructor
     * 
     * @param fileName
     * @throws FileNotFoundException
     */
    public CovidReader(String fileName) throws FileNotFoundException {
        data = readCovidFile(fileName);
        new GUIWindow(data);
    }


    /**
     * Parses the file and stores races into a linked list
     * and then creates states with the linked list passed
     * as a parameter which is then added to a linked list.
     * 
     * @param fileName
     * @return list - linked list
     * @throws FileNotFoundException
     */
    public LinkedList<State> readCovidFile(String fileName)
        throws FileNotFoundException {

        LinkedList<State> list = new LinkedList<State>();
        Scanner file = new Scanner(new File(fileName));

        // used for race names
        String[] temp = file.nextLine().split(", *");

        while (file.hasNextLine()) {
            LinkedList<Race> races = new LinkedList<Race>();
            String[] split = file.nextLine().split(", *");

            // handles the "NA" within the file
            for (int i = 0; i < split.length; i++) {
                if (split[i].equals("NA")) {
                    // need to change it to "-1" so Integer.valueOf can be used
                    split[i] = "-1";
                }
            }

            // gets cases/death info for each race from file
            // split.length/2 + 1 to account for using 2 columns at a time
            for (int i = 1; i < split.length / 2 + 1; i++) {
                // temp is used to store the race names
                String raceName = temp[i].substring(6).toLowerCase();

                int raceCases = Integer.valueOf(split[i]);

                // i + split.length/2 since cases and deaths are 5 columns apart
                int raceDeaths = Integer.valueOf(split[i + split.length / 2]);

                Race race = new Race(raceName, raceCases, raceDeaths);
                races.add(race);

            }

            // creates new state with name and linked list of races as
            // parameters
            State state = new State(split[0], races);
            list.add(state);
        }

        return list;
    }


    /**
     * Converts the list to a string
     * 
     * @return the string version
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < data.size(); i++) {
            builder.append(data.get(i).getName());
            builder.append("\n");
            builder.append(data.get(i).toStringAlphabetical());
            builder.append("=====");
            builder.append("\n");
            builder.append(data.get(i).toStringCFR());
            builder.append("=====");
            builder.append("\n");

        }
        return builder.toString();

    }

}
