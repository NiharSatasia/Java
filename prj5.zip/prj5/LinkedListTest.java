// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import java.util.Arrays;
import student.TestCase;

/**
 * LinkedList Test Class
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 2021.11.19
 *
 */
public class LinkedListTest extends TestCase {
    private LinkedList<String> list1;
    private LinkedList<String> list3;
    private LinkedList<String> emptyList;

    /**
     * Sets up tests
     */
    public void setUp() {
        list1 = new LinkedList<String>();
        list3 = new LinkedList<String>();
        list1.add("a");
        list1.add("b");
        list1.add("m");
        list1.add("k");
        list3.add("r");
        emptyList = new LinkedList<String>();

    }


    /**
     * tests ClearTo and ToArray methods
     */
    public void testClearToArray() {
        Object[] Array1 = { "a", "b", "m", "k" };
        Object[] halfArray = { "a", "b" };
        Object[] emptyArray = {};
        assertTrue(Arrays.equals(list1.toArray(), Array1));
        list1.clear();
        assertTrue(Arrays.equals(list1.toArray(), emptyArray));
        list1.add(0, "b");
        list1.add(0, "a");
        assertTrue(Arrays.equals(list1.toArray(), halfArray));
    }


    /**
     * tests Add method and Exceptions
     */
    public void testAdd() {

        Exception exception4 = null;
        try {
            list1.add(6, "r");
            fail("add() is not throwing an exception when it should");
        }
        catch (Exception e4) {
            exception4 = e4;
        }
        assertTrue("add() is throwing the wrong type of exceptions",
            exception4 instanceof IndexOutOfBoundsException);

        Exception exception = null;
        try {
            list1.add(6, null);
            fail("add() is not throwing an exception when it should");
        }
        catch (Exception e) {
            exception = e;
        }
        assertTrue("add() is throwing the wrong type of exceptions",
            exception instanceof IllegalArgumentException);

        Exception exception2 = null;
        try {
            list1.add(-1, "p");
            fail("add() is not throwing an exception when it should");
        }
        catch (Exception e2) {
            exception2 = e2;
        }
        assertTrue("add() is throwing the wrong type of exceptions",
            exception2 instanceof IndexOutOfBoundsException);

        Exception exception3 = null;
        try {
            list1.add(null);
            fail("add() is not throwing an exception when it should");
        }
        catch (Exception e3) {
            exception3 = e3;
        }
        assertTrue("add() is throwing the wrong type of exceptions",
            exception3 instanceof IllegalArgumentException);

        LinkedList<String> list2 = new LinkedList<String>();
        list2.add(0, "a");
        list2.add(1, "o");
        list2.add(2, "b");
        assertEquals("a", list2.get(0));
        assertEquals("o", list2.get(1));
        list2.add("g");
        assertEquals("g", list2.get(3));
        assertEquals(4, list1.size());
        list2.add(0, "r");
        assertEquals("r", list2.get(0));
        list1.add("p");
        list1.add("s");
        assertEquals("p", list1.get(4));
        assertEquals(6, list1.size());
        assertTrue(list1.contains("p"));
        assertFalse(list1.contains("t"));
        emptyList.add(0, "w");
    }


    /**
     * tests Remove method and exceptions
     */
    public void testRemove() {

        Exception exception = null;
        try {
            emptyList.remove(0);
            fail("remove() is not throwing an exception when it should");
        }
        catch (Exception e) {
            exception = e;
        }
        assertTrue("remove() is throwing the wrong type of exceptions",
            exception instanceof IndexOutOfBoundsException);

        Exception exception2 = null;
        try {
            list1.remove(-9);
            fail("remove() is not throwing an exception when it should");
        }
        catch (Exception e2) {
            exception2 = e2;
        }
        assertTrue("remove() is throwing the wrong type of exceptions",
            exception2 instanceof IndexOutOfBoundsException);

        Exception exception3 = null;
        try {
            list1.remove(50);
            fail("remove() is not throwing an exception when it should");
        }
        catch (Exception e3) {
            exception3 = e3;
        }
        assertTrue("remove() is throwing the wrong type of exceptions",
            exception3 instanceof IndexOutOfBoundsException);

        assertTrue(list1.remove("k"));
        assertEquals(3, list1.size());
        assertEquals(0, emptyList.size());
        assertEquals("m", list1.get(2));
        assertFalse(emptyList.remove("p"));
        assertFalse(list1.contains("k"));
        assertFalse(list1.remove("s"));
        list1.remove("b");
        assertEquals("a", list1.get(0));
        list1.remove("a");
        assertEquals("m", list1.get(0));
        assertTrue(list1.remove(0));
        assertEquals(1, list3.size());
        list3.add("m");
        list3.add("s");
        list3.add("t");
        list3.add("a");
        list3.add("b");
        assertTrue(list3.remove(4));
        assertEquals("r", list3.get(0));
        assertTrue(list3.remove(0));
        assertEquals("m", list3.get(0));
        assertFalse(emptyList.remove("r"));
        emptyList.add("m");
        emptyList.remove(0);
        assertFalse(list1.remove("r"));

    }


    /**
     * tests Get method and exceptions
     */
    public void testGet() {
        Exception exception = null;
        try {
            list1.get(-1);
            fail("get() is not throwing an exception when it should");
        }
        catch (Exception e) {
            exception = e;
        }
        assertTrue("get() is throwing the wrong type of exceptions",
            exception instanceof IndexOutOfBoundsException);

        list1.get(0);
        assertEquals("a", list1.get(0));
    }


    /**
     * tests isEmpty and Clear method
     */
    public void testisEmptyandClear() {
        assertEquals(4, list1.size());
        list1.clear();
        assertTrue(list1.isEmpty());
        list1.clear();
        assertEquals(0, list1.size());

    }


    /**
     * tests Contains method
     */
    public void testContains() {
        assertTrue(list1.contains("a"));
        assertFalse(list1.contains("g"));
        list1.add("s");
        assertTrue(list1.contains("s"));
    }


    /**
     * tests lastIndexOf method
     */
    public void testlastIndexOf() {
        assertEquals(0, list1.lastIndexOf("a"));
        list1.add("p");
        assertEquals(4, list1.lastIndexOf("p"));

    }


    /**
     * tests toString method
     */
    public void testtoString() {
        assertEquals("{a, b, m, k}", list1.toString());

    }
}
