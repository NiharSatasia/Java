// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

import java.text.DecimalFormat;

/**
 * Creates race object
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class Race {

    private String rName;
    private int rCases;
    private int rDeaths;
    private double cFr;

    /**
     * Constructor for race
     * 
     * @param ethnicity
     *            - name of ethnicity
     * @param cases
     *            - number of cases
     * @param deaths
     *            - number of deaths
     */
    public Race(String ethnicity, int cases, int deaths) {
        this.rName = ethnicity;
        this.rCases = cases;
        this.rDeaths = deaths;
        this.cFr = covidCalculator();
    }


    /**
     * Getter for name
     * 
     * @return rName - name of race
     */
    public String getName() {
        return rName;
    }


    /**
     * Getter for cases
     * 
     * @return rCases - number of cases
     */
    public double getCases() {
        return rCases;
    }


    /**
     * Getter for Deaths
     * 
     * @return rDeaths - number of deaths
     */
    public double getDeaths() {
        return rDeaths;
    }


    /**
     * Getter for CFR
     * 
     * @return CFR - value of CFR
     */
    public double getCFR() {
        return cFr;
    }


    /**
     * Calculates CFR
     * 
     * @return CFR - covid fatality rate
     */
    public double covidCalculator() {
        if (rCases == -1 || rDeaths == -1) {
            cFr = -1.0;
        }
        else {
            cFr = ((double)rDeaths / (double)rCases) * 100.00;
        }

        return cFr;
    }


    /**
     * Compares the races alphabetically
     * 
     * @param other
     *            - race object to compare to
     * @return 1, 0, or -1 depending on the comparison
     */
    public int compareAlpha(Race other) {
        return this.getName().compareTo(other.getName());
    }


    /**
     * Compares the races by CFR
     * 
     * @param other
     *            - race object to compare to
     * @return 1, 0, or -1 depending on the comparison
     */
    public int compareCFR(Race other) {
        if (Double.valueOf(this.covidCalculator()) > Double.valueOf(other
            .covidCalculator())) {
            return 1;
        }
        if (Double.valueOf(this.covidCalculator()) < Double.valueOf(other
            .covidCalculator())) {
            return -1;
        }
        return other.getName().compareTo(this.getName());
    }


    /**
     * Converts the race to a string
     * 
     * @return the string version
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(rName + ": ");
        DecimalFormat d = new DecimalFormat("#.#");
        String sCFR = d.format(cFr);
        s.append(rCases + " cases, ");
        s.append(sCFR + "% CFR ");
        return s.toString();
    }

}
