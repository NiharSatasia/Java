// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with
// honor and integrity at all times.
// I will not lie, cheat, or steal,
// nor will I accept the actions of those who do.
// -- Burke Butler (burkeb) Nihar Satasia (niharsatasia) Tejasvi Iyer (tejiyer6)
package prj5;

/**
 * Creates state object
 * 
 * @author Nihar Satasia (niharsatasia)
 * @author Tejasvi Iyer (tejiyer6)
 * @author Burke Butler (burkeb)
 * @version 11.19.21
 *
 */
public class State {

    private String name;
    private LinkedList<Race> list;

    /**
     * State constructor
     * 
     * @param name1
     *            - name of state
     * @param races
     *            - the linked list being used
     */
    public State(String name1, LinkedList<Race> races) {
        this.name = name1;
        this.list = races;
    }


    /**
     * Getter for state name
     * 
     * @return name - name of state
     */
    public String getName() {
        return name;
    }


    /**
     * Getter for linked list
     * 
     * @return list - the linked list
     */
    public LinkedList<Race> getList() {
        return list;
    }


    /**
     * Converts the state to string
     * 
     * @return the string version
     */
    public String toStringAlphabetical() {
        StringBuilder s = new StringBuilder();
        LinkedList<Race> temp = sortAlpha(list);
        for (int i = 0; i < temp.size(); i++) {
            s.append(temp.get(i) + "\n");
        }

        return s.toString();
    }


    private LinkedList<Race> sortAlpha(LinkedList<Race> list1) {
        Race[] temp = new Race[list1.size()];
        for (int i = 0; i < list1.size(); i++) {
            temp[i] = list1.get(i);
        }
        for (int i = 0; i < list1.size(); i++) {
            for (int j = 0; j < list1.size(); j++) {
                if (temp[i].getName().toCharArray()[0] < temp[j].getName()
                    .toCharArray()[0]) {
                    Race newTemp = temp[i];
                    temp[i] = temp[j];
                    temp[j] = newTemp;
                }
            }
        }

        LinkedList<Race> returnList = new LinkedList<Race>();
        for (int i = 0; i < list1.size(); i++) {
            returnList.add(temp[i]);
        }
        return returnList;

    }


    /**
     * Converts the state to string
     * 
     * @return the string version
     */
    public String toStringCFR() {
        StringBuilder s = new StringBuilder();
        LinkedList<Race> temp = sortCFR(list);
        for (int i = 0; i < temp.size(); i++) {
            s.append(temp.get(i) + "\n");
        }

        return s.toString();
    }


    private LinkedList<Race> sortCFR(LinkedList<Race> list2) {
        Race[] temp = new Race[list2.size()];
        for (int i = 0; i < list2.size(); i++) {
            temp[i] = list2.get(i);
        }
        for (int i = 0; i < list2.size(); i++) {
            for (int j = 0; j < list2.size(); j++) {
                if (temp[i].getCFR() > temp[j].getCFR()) {
                    Race newTemp = temp[i];
                    temp[i] = temp[j];
                    temp[j] = newTemp;
                }
            }
        }

        LinkedList<Race> returnList = new LinkedList<Race>();
        for (int i = 0; i < list2.size(); i++) {
            returnList.add(temp[i]);
        }
        return returnList;

    }

}
